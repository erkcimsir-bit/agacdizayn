<?php
/**
 * Ağaç Dizayn - Test Paneli
 */

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Test Paneli - Ağaç Dizayn</title>";
echo "<style>";
echo "* { margin: 0; padding: 0; box-sizing: border-box; }";
echo "body { font-family: Arial, sans-serif; background: #f8f9fa; padding: 2rem; }";
echo ".container { max-width: 800px; margin: 0 auto; background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }";
echo "h2 { color: #333; margin-top: 2rem; margin-bottom: 1rem; border-bottom: 2px solid #667eea; padding-bottom: 0.5rem; }";
echo "h3 { color: #666; margin: 1rem 0 0.5rem; }";
echo "p { margin: 0.5rem 0; }";
echo ".success { color: #28a745; }";
echo ".error { color: #dc3545; }";
echo ".badge { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600; background: #f0f0f0; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";
echo "<h1>🌲 Ağaç Dizayn - Test Paneli</h1>";

// Config dosyası kontrolü
echo "<h2>✅ Konfigürasyon Kontrolü</h2>";
if (file_exists('config/database.php')) {
    require_once 'config/database.php';
    echo "<p class='success'>✓ Database config yüklendi</p>";
} else {
    echo "<p class='error'>✗ Database config bulunamadı</p>";
}

if (file_exists('config/config.php')) {
    require_once 'config/config.php';
    echo "<p class='success'>✓ Config yüklendi</p>";
} else {
    echo "<p class='error'>✗ Config bulunamadı</p>";
}

// PHP Sürümü
echo "<h2>✅ PHP Bilgileri</h2>";
echo "<p><strong>PHP Sürümü:</strong> " . phpversion() . "</p>";

// Veritabanı Bağlantısı
echo "<h2>✅ Veritabanı Bağlantısı</h2>";
try {
    $pdo->query("SELECT 1");
    echo "<p class='success'>✓ Veritabanına bağlı</p>";
    
    // Tabloları kontrol et
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll();
    echo "<p><strong>Toplam tablo:</strong> " . count($tables) . "</p>";
    
    if (count($tables) > 0) {
        echo "<h3>Tablolar:</h3>";
        echo "<ul>";
        foreach ($tables as $table) {
            $table_name = array_values($table)[0];
            echo "<li>📊 " . $table_name . "</li>";
        }
        echo "</ul>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>✗ Veritabanı hatası: " . $e->getMessage() . "</p>";
}

// Dosya Yolları
echo "<h2>✅ Dosya Yolları</h2>";
echo "<p><strong>SITE_URL:</strong> " . (defined('SITE_URL') ? SITE_URL : 'Tanımlanmamış') . "</p>";
echo "<p><strong>UPLOAD_PATH:</strong> " . (defined('UPLOAD_PATH') ? UPLOAD_PATH : 'Tanımlanmamış') . "</p>";
echo "<p><strong>LOG_PATH:</strong> " . (defined('LOG_PATH') ? LOG_PATH : 'Tanımlanmamış') . "</p>";

// Yazılabilirlik Kontrolü
echo "<h2>✅ Yazılabilirlik Kontrolü</h2>";
echo "<p>" . (is_writable('uploads') ? "<span class='success'>✓</span>" : "<span class='error'>✗</span>") . " uploads klasörü</p>";
echo "<p>" . (is_writable('logs') ? "<span class='success'>✓</span>" : "<span class='error'>✗</span>") . " logs klasörü</p>";

echo "<h2 style='color: #28a745;'>✅ Test Tamamlandı!</h2>";
echo "<p><a href='javascript:location.reload()' style='padding: 0.5rem 1rem; background: #667eea; color: white; text-decoration: none; border-radius: 4px; display: inline-block;'>Yenile</a></p>";

echo "</div>";
echo "</body>";
echo "</html>";
?>