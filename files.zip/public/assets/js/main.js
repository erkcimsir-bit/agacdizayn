/**
 * XBT Yazılım Hizmetleri - Ana JavaScript Dosyası
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // Slider Fonksiyonu
    initSlider();
    
    // Menu Toggle (Mobile)
    initMobileMenu();
    
    // Smooth Scroll
    initSmoothScroll();
});

/**
 * Slider Başlat
 */
function initSlider() {
    const slides = document.querySelectorAll('.slide');
    if (slides.length === 0) return;
    
    let currentSlide = 0;
    
    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.style.opacity = i === index ? '1' : '0';
        });
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }
    
    // İlk slaydı göster
    showSlide(0);
    
    // Her 5 saniyede bir sonraki slayda geç
    setInterval(nextSlide, 5000);
}

/**
 * Mobil Menüyü Başlat
 */
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navbarMenu = document.querySelector('.navbar-menu');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            navbarMenu.classList.toggle('active');
        });
    }
}

/**
 * Smooth Scroll
 */
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

/**
 * Form Gönder
 */
function submitForm(formId, url) {
    const form = document.getElementById(formId);
    const formData = new FormData(form);
    
    fetch(url, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('İşlem başarılı!');
            form.reset();
        } else {
            alert('Hata: ' + data.message);
        }
    })
    .catch(error => console.error('Hata:', error));
}

/**
 * Admin Panel - Modal
 */
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
    }
}

// Modal dışında click yapılırsa kapat
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});