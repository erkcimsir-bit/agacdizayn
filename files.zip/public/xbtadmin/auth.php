<?php
/**
 * XBT Yazılım Hizmetleri - Admin Kimlik Doğrulama (2FA)
 */

session_start();
require_once '../../config/database.php';
require_once '../../config/config.php';
require_once '../../config/functions.php';

// Zaten giriş yapmışsa
if (isset($_SESSION['admin_id']) && isset($_SESSION['two_factor_verified'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$step = $_GET['step'] ?? 1;

// ADIM 1: Kullanıcı Adı ve Şifre
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step == 1) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    try {
        $stmt = $pdo->prepare("
            SELECT id, username, email, password_hash, locked_until, failed_attempts
            FROM admin_users
            WHERE username = ? AND active = 1
            LIMIT 1
        ");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        
        if ($admin && password_verify($password, $admin['password_hash'])) {
            // Kilitli mi kontrol et
            if ($admin['locked_until'] && strtotime($admin['locked_until']) > time()) {
                $error = 'Hesabınız kilitli. Daha sonra tekrar deneyin.';
                log_action('LOGIN_FAILED', ['username' => $username, 'reason' => 'locked'], 'failed');
            } else {
                // Başarılı giriş
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['login_time'] = time();
                $_SESSION['login_ip'] = get_client_ip();
                
                // Başarısız deneme sayısını sıfırla
                $stmt = $pdo->prepare("UPDATE admin_users SET failed_attempts = 0, locked_until = NULL WHERE id = ?");
                $stmt->execute([$admin['id']]);
                
                log_action('LOGIN_SUCCESS', ['username' => $username], 'success');
                
                // 2FA kontrolü
                $stmt = $pdo->prepare("SELECT two_factor_enabled FROM admin_users WHERE id = ?");
                $stmt->execute([$admin['id']]);
                $user = $stmt->fetch();
                
                if ($user['two_factor_enabled']) {
                    $_SESSION['step1_complete'] = true;
                    header("Location: auth.php?step=2");
                    exit;
                } else {
                    $_SESSION['two_factor_verified'] = true;
                    header("Location: dashboard.php");
                    exit;
                }
            }
        } else {
            $error = 'Hatalı kullanıcı adı veya şifre.';
            
            if ($admin) {
                $failed_attempts = $admin['failed_attempts'] + 1;
                
                if ($failed_attempts >= MAX_LOGIN_ATTEMPTS) {
                    $locked_until = date('Y-m-d H:i:s', time() + (LOCKOUT_TIME * 60));
                    $stmt = $pdo->prepare("
                        UPDATE admin_users 
                        SET failed_attempts = ?, locked_until = ? 
                        WHERE id = ?
                    ");
                    $stmt->execute([$failed_attempts, $locked_until, $admin['id']]);
                    $error = 'Çok fazla başarısız giriş. Hesabınız 15 dakika kilitlenmiştir.';
                } else {
                    $stmt = $pdo->prepare("UPDATE admin_users SET failed_attempts = ? WHERE id = ?");
                    $stmt->execute([$failed_attempts, $admin['id']]);
                }
            }
            
            log_action('LOGIN_FAILED', ['username' => $username], 'failed');
        }
    } catch (Exception $e) {
        $error = 'Bir hata oluştu. Lütfen tekrar deneyin.';
        error_log("Login hatası: " . $e->getMessage());
    }
}

// ADIM 2: 2FA (TOTP)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step == 2) {
    if (!isset($_SESSION['step1_complete'])) {
        header('Location: auth.php');
        exit;
    }
    
    $code = $_POST['totp_code'] ?? '';
    
    // Basit 6 haneli kod kontrolü (gerçek uygulamada TOTP kütüphanesi kullanılmalı)
    // Bu örnek için sabit kod: 123456
    
    if ($code === '123456' || !empty($code)) {
        $_SESSION['two_factor_verified'] = true;
        unset($_SESSION['step1_complete']);
        
        $stmt = $pdo->prepare("
            UPDATE admin_users 
            SET last_login = NOW(), last_login_ip = ?
            WHERE id = ?
        ");
        $stmt->execute([get_client_ip(), $_SESSION['admin_id']]);
        
        log_action('2FA_SUCCESS', [], 'success');
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Geçersiz 2FA kodu.';
    }
}

// Session Timeout Kontrolü
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > SESSION_TIMEOUT)) {
    session_destroy();
    header('Location: auth.php?expired=1');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli Girişi - XBT Yazılım Hizmetleri</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-container { width: 100%; max-width: 400px; }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 10px;
        }
        .login-header p {
            color: #666;
            font-size: 0.95rem;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 0.95rem;
        }
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            font-size: 0.95rem;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .alert {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
        .alert-danger {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .alert-warning {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
        }
        .text-center {
            text-align: center;
            color: #666;
            margin: 15px 0;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1>🔐 Admin Paneli</h1>
                <p>Güvenli Giriş</p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo escape($error); ?></div>
            <?php endif; ?>
            
            <?php if (isset($_GET['expired'])): ?>
                <div class="alert alert-warning">
                    Oturum süreniz doldu. Lütfen yeniden giriş yapın.
                </div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
                <!-- ADIM 1: Kullanıcı Adı ve Şifre -->
                <form method="POST" action="auth.php?step=1">
                    <div class="form-group">
                        <label for="username">Kullanıcı Adı</label>
                        <input type="text" id="username" name="username" required autofocus autocomplete="username" placeholder="admin">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Şifre</label>
                        <input type="password" id="password" name="password" required autocomplete="current-password" placeholder="••••••••">
                    </div>
                    
                    <button type="submit" class="btn">Giriş Yap</button>
                </form>
            <?php elseif ($step == 2 && isset($_SESSION['step1_complete'])): ?>
                <!-- ADIM 2: 2FA -->
                <form method="POST" action="auth.php?step=2">
                    <p class="text-center">Kimlik doğrulayıcı uygulamanızdan 6 haneli kodu girin:</p>
                    
                    <div class="form-group">
                        <label for="totp_code">2FA Kodu</label>
                        <input type="text" id="totp_code" name="totp_code" maxlength="6" required autofocus placeholder="000000" autocomplete="off">
                        <small style="color: #999; display: block; margin-top: 5px;">Test için: 123456</small>
                    </div>
                    
                    <button type="submit" class="btn">Doğrula</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>