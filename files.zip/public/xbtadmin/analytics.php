<?php
/**
 * XBT Yazılım Hizmetleri - Ziyaretçi Analizi
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$filter_days = $_GET['days'] ?? 30;

// Günlük Ziyaretçi Sayıları
$stmt = $pdo->prepare("
    SELECT 
        DATE(created_at) as date,
        COUNT(DISTINCT ip_address, session_id) as visitors,
        COUNT(*) as page_views
    FROM visitor_analytics
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    GROUP BY DATE(created_at)
    ORDER BY date ASC
");
$stmt->execute([$filter_days]);
$daily_stats = $stmt->fetchAll();

// Ülkelere Göre Ziyaretçiler
$stmt = $pdo->prepare("
    SELECT 
        country,
        country_code,
        COUNT(DISTINCT ip_address) as visitor_count,
        COUNT(*) as page_views
    FROM visitor_analytics
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) AND country IS NOT NULL
    GROUP BY country, country_code
    ORDER BY visitor_count DESC
    LIMIT 20
");
$stmt->execute([$filter_days]);
$country_stats = $stmt->fetchAll();

// Şehirlere Göre Ziyaretçiler
$stmt = $pdo->prepare("
    SELECT 
        city,
        region,
        country,
        COUNT(DISTINCT ip_address) as visitor_count
    FROM visitor_analytics
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) AND city IS NOT NULL
    GROUP BY city, region, country
    ORDER BY visitor_count DESC
    LIMIT 15
");
$stmt->execute([$filter_days]);
$city_stats = $stmt->fetchAll();

// En Çok Ziyaret Edilen Sayfalar
$stmt = $pdo->prepare("
    SELECT 
        page_visited,
        COUNT(*) as view_count,
        COUNT(DISTINCT ip_address) as unique_visitors
    FROM visitor_analytics
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    GROUP BY page_visited
    ORDER BY view_count DESC
    LIMIT 10
");
$stmt->execute([$filter_days]);
$page_stats = $stmt->fetchAll();

// Genel İstatistikler
$stmt = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT ip_address) as total_visitors,
        COUNT(DISTINCT session_id) as total_sessions,
        COUNT(*) as total_page_views,
        AVG(visit_duration) as avg_duration
    FROM visitor_analytics
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
");
$stmt->execute([$filter_days]);
$overall_stats = $stmt->fetch();

// Engelli IP'ler
$stmt = $pdo->prepare("
    SELECT COUNT(*) as total FROM blocked_ips
");
$stmt->execute();
$blocked_ips_count = $stmt->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ziyaretçi Analizi - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Ziyaretçi Analizi</h1>
                <div class="top-bar-right">
                    <select id="filter-days" class="form-control" style="width: 150px;">
                        <option value="7" <?php echo ($filter_days == 7 ? 'selected' : ''); ?>>Son 7 Gün</option>
                        <option value="30" <?php echo ($filter_days == 30 ? 'selected' : ''); ?>>Son 30 Gün</option>
                        <option value="90" <?php echo ($filter_days == 90 ? 'selected' : ''); ?>>Son 90 Gün</option>
                    </select>
                </div>
            </header>
            
            <div class="container-fluid">
                <!-- Genel İstatistikler -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #e7f3ff;">
                            <i class="icon-users" style="color: #0066cc;">👥</i>
                        </div>
                        <div class="stat-info">
                            <h3><?php echo number_format($overall_stats['total_visitors'] ?? 0); ?></h3>
                            <p>Toplam Ziyaretçi</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #f0e7ff;">
                            <i class="icon-session" style="color: #6600cc;">📊</i>
                        </div>
                        <div class="stat-info">
                            <h3><?php echo number_format($overall_stats['total_sessions'] ?? 0); ?></h3>
                            <p>Toplam Oturumlar</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #e7f9f5;">
                            <i class="icon-page" style="color: #009900;">📄</i>
                        </div>
                        <div class="stat-info">
                            <h3><?php echo number_format($overall_stats['total_page_views'] ?? 0); ?></h3>
                            <p>Toplam Sayfa Görüntülenme</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #fff5e7;">
                            <i class="icon-block" style="color: #ff9900;">🚫</i>
                        </div>
                        <div class="stat-info">
                            <h3><?php echo $blocked_ips_count; ?></h3>
                            <p>Engelli IP Adresleri</p>
                        </div>
                    </div>
                </div>
                
                <!-- Grafikler -->
                <div class="charts-grid">
                    <!-- Günlük Ziyaretçiler -->
                    <div class="chart-container">
                        <h4>Günlük Ziyaretçiler</h4>
                        <canvas id="dailyVisitorsChart"></canvas>
                    </div>
                    
                    <!-- Ülkelere Göre Dağılım -->
                    <div class="chart-container">
                        <h4>En Çok Ziyaret Eden Ülkeler</h4>
                        <canvas id="countryChart"></canvas>
                    </div>
                </div>
                
                <!-- Tablolar -->
                <div class="row">
                    <!-- En Çok Ziyaret Edilen Sayfalar -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>En Çok Ziyaret Edilen Sayfalar</h5>
                            </div>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Sayfa</th>
                                        <th>Görüntüleme</th>
                                        <th>Benzersiz Ziyaretçi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($page_stats as $page): ?>
                                        <tr>
                                            <td><code style="font-size: 0.8rem;"><?php echo escape(substr($page['page_visited'], 0, 40)); ?></code></td>
                                            <td><?php echo $page['view_count']; ?></td>
                                            <td><?php echo $page['unique_visitors']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Şehirlere Göre Ziyaretçiler -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Şehirlere Göre Ziyaretçiler</h5>
                            </div>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Şehir</th>
                                        <th>Bölge</th>
                                        <th>Ziyaretçi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($city_stats as $city): ?>
                                        <tr>
                                            <td><?php echo escape($city['city'] ?? '-'); ?></td>
                                            <td><?php echo escape($city['region'] ?? $city['country']); ?></td>
                                            <td><?php echo $city['visitor_count']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Ülkelere Göre Detaylı Tablo -->
                <div class="card" style="margin-top: 2rem;">
                    <div class="card-header">
                        <h5>Ülkelere Göre Ziyaretçiler (Detaylı)</h5>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ülke</th>
                                <th>Kod</th>
                                <th>Ziyaretçi</th>
                                <th>Sayfa Görüntülenme</th>
                            </tr>
                        </thead>
                        <tbody>
                            