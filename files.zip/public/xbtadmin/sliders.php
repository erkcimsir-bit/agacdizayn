<?php
/**
 * XBT Yazılım Hizmetleri - Sliders Yönetimi
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$language_id = $_GET['lang'] ?? 1;

// Sliders'ı Getir
$stmt = $pdo->prepare("
    SELECT * FROM sliders 
    WHERE language_id = ?
    ORDER BY sort_order
");
$stmt->execute([$language_id]);
$sliders = $stmt->fetchAll();

// Dilleri Getir
$stmt = $pdo->query("SELECT id, code, name FROM languages WHERE active = 1");
$languages = $stmt->fetchAll();

// Slider Ekle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $button_text = $_POST['button_text'] ?? '';
    $link = $_POST['link'] ?? '';
    
    try {
        // Resim yükleme
        $image_path = null;
        if (!empty($_FILES['image']['tmp_name'])) {
            $result = upload_image($_FILES['image'], 'sliders');
            if ($result['success']) {
                $image_path = $result['url'];
            } else {
                throw new Exception('Resim yükleme başarısız');
            }
        }
        
        // Sort order en yükseği al
        $stmt = $pdo->prepare("SELECT MAX(sort_order) as max_order FROM sliders WHERE language_id = ?");
        $stmt->execute([$language_id]);
        $max_order = $stmt->fetch()['max_order'] ?? 0;
        
        $stmt = $pdo->prepare("
            INSERT INTO sliders (language_id, title, description, image, button_text, link, sort_order)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $language_id,
            $title,
            $description,
            $image_path,
            $button_text,
            $link,
            $max_order + 1
        ]);
        
        $message = 'Slider başarıyla eklendi.';
        log_action('ADD_SLIDER', ['title' => $title], 'success');
        
        header("Location: " . ADMIN_PATH . "/sliders.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
        log_action('ADD_SLIDER', ['title' => $title], 'failed');
    }
}

// Slider Sil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $slider_id = $_POST['slider_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM sliders WHERE id = ? AND language_id = ?");
        $stmt->execute([$slider_id, $language_id]);
        
        $message = 'Slider başarıyla silindi.';
        log_action('DELETE_SLIDER', ['id' => $slider_id], 'success');
        
        header("Location: " . ADMIN_PATH . "/sliders.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}

// Slider Sırasını Güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_order') {
    $orders = $_POST['orders'] ?? [];
    
    try {
        foreach ($orders as $slider_id => $order) {
            $stmt = $pdo->prepare("UPDATE sliders SET sort_order = ? WHERE id = ? AND language_id = ?");
            $stmt->execute([$order, $slider_id, $language_id]);
        }
        
        $message = 'Sıra başarıyla güncellendi.';
        log_action('UPDATE_SLIDER_ORDER', [], 'success');
        
        header("Location: " . ADMIN_PATH . "/sliders.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sliders - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Sliders (Ana Sayfa Görselleri)</h1>
                <button class="btn btn-primary" data-toggle="modal" data-target="#addSliderModal">
                    <i class="icon-plus"></i> Yeni Slider
                </button>
            </header>
            
            <div class="container-fluid">
                <!-- Dil Seçimi -->
                <div class="form-group">
                    <label for="language_select">Dil Seçin:</label>
                    <select id="language_select" class="form-control" style="width: 200px;">
                        <?php foreach ($languages as $lang): ?>
                            <option value="<?php echo $lang['id']; ?>" 
                                    <?php echo ($lang['id'] == $language_id ? 'selected' : ''); ?>>
                                <?php echo escape($lang['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5>Sliders Listesi (Sürükle-Bırak ile Sırala)</h5>
                    </div>
                    <div class="card-body">
                        <div class="sliders-list" id="sliders-list">
                            <?php if (empty($sliders)): ?>
                                <p class="text-center">Henüz slider eklenmemiştir.</p>
                            <?php else: ?>
                                <?php foreach ($sliders as $slider): ?>
                                    <div class="slider-item" data-id="<?php echo $slider['id']; ?>" style="background: white; padding: 15px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; cursor: move;">
                                        <div style="display: flex; gap: 15px;">
                                            <div style="flex: 0 0 150px;">
                                                <img src="<?php echo escape($slider['image']); ?>" alt="<?php echo escape($slider['title']); ?>" style="width: 100%; height: auto; border-radius: 4px;">
                                            </div>
                                            <div style="flex: 1;">
                                                <h5><?php echo escape($slider['title']); ?></h5>
                                                <p><?php echo escape(substr($slider['description'], 0, 100)); ?>...</p>
                                                <p><small><strong>Bağlantı:</strong> <?php echo escape($slider['link']); ?></small></p>
                                            </div>
                                            <div style="flex: 0 0 150px;">
                                                <a href="<?php echo ADMIN_PATH; ?>/slider-edit.php?id=<?php echo $slider['id']; ?>" class="btn btn-primary btn-sm" style="width: 100%; margin-bottom: 5px;">Düzenle</a>
                                                <form method="POST" style="display: inline; width: 100%;">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="slider_id" value="<?php echo $slider['id']; ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" style="width: 100%;" onclick="return confirm('Emin misiniz?')">Sil</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal: Slider Ekle -->
    <div class="modal" id="addSliderModal">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Yeni Slider Ekle</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="form-group">
                            <label for="title">Başlık *</label>
                            <input type="text" id="title" name="title" required class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Açıklama</label>
                            <textarea id="description" name="description" rows="3" class="form-control"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="image">Resim (Mobil için otomatik ölçeklenecek) *</label>
                            <input type="file" id="image" name="image" accept="image/*" required class="form-control">
                            <small class="form-text text-muted">Önerilen boyut: 1920x600px</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="button_text">Buton Metni</label>
                            <input type="text" id="button_text" name="button_text" class="form-control" placeholder="Örn: Daha Fazla">
                        </div>
                        
                        <div class="form-group">
                            <label for="link">Bağlantı</label>
                            <input type="text" id="link" name="link" class="form-control" placeholder="https://...">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Ekle</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
    <script>
        document.getElementById('language_select').addEventListener('change', function() {
            window.location.href = '<?php echo ADMIN_PATH; ?>/sliders.php?lang=' + this.value;
        });
        
        // Sortable - Sürükle-Bırak
        new Sortable(document.getElementById('sliders-list'), {
            animation: 150,
            ghostClass: 'sortable-ghost',
            onChange: function() {
                updateOrder();
            }
        });
        
        function updateOrder() {
            const items = document.querySelectorAll('.slider-item');
            const orders = {};
            
            items.forEach((item, index) => {
                orders[item.dataset.id] = index + 1;
            });
            
            // Form oluştur ve gönder
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            form.innerHTML = '<input type="hidden" name="action" value="update_order">';
            
            for (const [id, order] of Object.entries(orders)) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'orders[' + id + ']';
                input.value = order;
                form.appendChild(input);
            }
            
            document.body.appendChild(form);
            form.submit();
        }
        
        // Modal işlevleri
        document.querySelectorAll('[data-toggle="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                document.querySelector(targetId).classList.add('show');
            });
        });
        
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                this.closest('.modal').classList.remove('show');
            });
        });
    </script>
</body>
</html>