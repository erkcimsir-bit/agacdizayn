<?php
/**
 * XBT Yazılım Hizmetleri - Genel Site Ayarları
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$settings = get_site_settings();

// Ayarları Güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = $_POST['site_name'] ?? '';
    $site_description = $_POST['site_description'] ?? '';
    $site_keywords = $_POST['site_keywords'] ?? '';
    
    try {
        $stmt = $pdo->prepare("
            UPDATE site_settings 
            SET site_name = ?, site_description = ?, site_keywords = ?
            WHERE id = 1
        ");
        $stmt->execute([$site_name, $site_description, $site_keywords]);
        
        // Logo Yükleme
        if (!empty($_FILES['logo']['tmp_name'])) {
            $logo_result = upload_image($_FILES['logo'], 'logos');
            if ($logo_result['success']) {
                $stmt = $pdo->prepare("UPDATE site_settings SET logo_path = ? WHERE id = 1");
                $stmt->execute([$logo_result['url']]);
            }
        }
        
        // Favicon Yükleme
        if (!empty($_FILES['favicon']['tmp_name'])) {
            $favicon_result = upload_image($_FILES['favicon'], 'favicon');
            if ($favicon_result['success']) {
                $stmt = $pdo->prepare("UPDATE site_settings SET favicon_path = ? WHERE id = 1");
                $stmt->execute([$favicon_result['url']]);
            }
        }
        
        $message = 'Ayarlar başarıyla güncellendi.';
        $settings = get_site_settings();
        log_action('UPDATE_SETTINGS', ['site_name' => $site_name], 'success');
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
        log_action('UPDATE_SETTINGS', [], 'failed');
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Ayarları - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Genel Site Ayarları</h1>
            </header>
            
            <div class="container-fluid">
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="site_name">Site Adı *</label>
                                <input type="text" id="site_name" name="site_name" 
                                       value="<?php echo escape($settings['site_name'] ?? ''); ?>" 
                                       required class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="site_description">Site Açıklaması</label>
                                <textarea id="site_description" name="site_description" 
                                          class="form-control" rows="4"><?php echo escape($settings['site_description'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="site_keywords">Anahtar Kelimeler (virgülle ayırın)</label>
                                <textarea id="site_keywords" name="site_keywords" 
                                          class="form-control" rows="3"><?php echo escape($settings['site_keywords'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="logo">Logo</label>
                                <?php if (!empty($settings['logo_path'])): ?>
                                    <div class="image-preview">
                                        <img src="<?php echo escape($settings['logo_path']); ?>" alt="Logo" style="max-width: 200px;">
                                    </div>
                                <?php endif; ?>
                                <input type="file" id="logo" name="logo" accept="image/*" class="form-control">
                                <small class="form-text text-muted">PNG, JPG, GIF, WebP (Max 5MB)</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="favicon">Favicon (32x32 PNG)</label>
                                <?php if (!empty($settings['favicon_path'])): ?>
                                    <div class="image-preview">
                                        <img src="<?php echo escape($settings['favicon_path']); ?>" alt="Favicon" style="max-width: 50px;">
                                    </div>
                                <?php endif; ?>
                                <input type="file" id="favicon" name="favicon" accept="image/*" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>