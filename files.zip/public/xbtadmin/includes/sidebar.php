<?php
/**
 * Admin Panel Sidebar
 */
?>
<style>
    .admin-sidebar {
        width: 250px;
        background: #2c3e50;
        color: white;
        position: fixed;
        left: 0;
        top: 0;
        height: 100vh;
        overflow-y: auto;
        padding: 2rem 0;
        z-index: 1000;
    }
    
    .sidebar-brand {
        padding: 0 1.5rem;
        margin-bottom: 2rem;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        padding-bottom: 1.5rem;
    }
    
    .sidebar-brand h2 {
        margin: 0;
        color: white;
    }
    
    .sidebar-menu ul {
        list-style: none;
        padding: 0;
    }
    
    .sidebar-menu li a {
        display: block;
        padding: 0.75rem 1.5rem;
        color: rgba(255,255,255,0.7);
        text-decoration: none;
        transition: all 0.3s;
        border-left: 3px solid transparent;
    }
    
    .sidebar-menu li a:hover,
    .sidebar-menu li a.active {
        background: rgba(255,255,255,0.1);
        border-left-color: #667eea;
        color: white;
    }
    
    .sidebar-menu .menu-title {
        padding: 1rem 1.5rem 0.5rem;
        font-size: 0.85rem;
        font-weight: 600;
        color: rgba(255,255,255,0.5);
        text-transform: uppercase;
    }
    
    .main-wrapper {
        margin-left: 250px;
    }
</style>

<aside class="admin-sidebar">
    <div class="sidebar-brand">
        <h2>🔐 XBT Admin</h2>
    </div>
    
    <nav class="sidebar-menu">
        <ul>
            <li><a href="dashboard.php" class="<?php echo (strpos($_SERVER['PHP_SELF'], 'dashboard') ? 'active' : ''); ?>">📊 Dashboard</a></li>
            
            <li class="menu-title">Ayarlar</li>
            <li><a href="settings.php" class="<?php echo (strpos($_SERVER['PHP_SELF'], 'settings') ? 'active' : ''); ?>">⚙️ Genel Ayarlar</a></li>
            <li><a href="settings-seo.php">🔍 SEO Ayarları</a></li>
            <li><a href="settings-smtp.php">📧 E-posta (SMTP)</a></li>
            
            <li class="menu-title">İçerik</li>
            <li><a href="pages.php">📄 Sayfalar</a></li>
            <li><a href="categories.php">📂 Kategoriler</a></li>
            <li><a href="products.php">📦 Ürünler</a></li>
            <li><a href="sliders.php">🖼️ Sliders</a></li>
            
            <li class="menu-title">İletişim & Analiz</li>
            <li><a href="messages.php">💬 Mesajlar</a></li>
            <li><a href="analytics.php">📈 Ziyaretçi Analizi</a></li>
            
            <li class="menu-title">Yönetim</li>
            <li><a href="languages.php">🌐 Diller</a></li>
            <li><a href="menus.php">📋 Menüler</a></li>
            <li><a href="blocked-ips.php">🚫 Engelli IP'ler</a></li>
            <li><a href="security-logs.php">🔒 Güvenlik Logları</a></li>
        </ul>
    </nav>
</aside>

<script>
    // Aktif sayfa gösterimi
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-menu a').forEach(link => {
        if (link.getAttribute('href') && currentPath.includes(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
</script>