<?php
/**
 * XBT Yazılım Hizmetleri - Mesaj Detay ve Cevap
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$msg_id = $_GET['id'] ?? 0;

// Mesajı Getir
$stmt = $pdo->prepare("SELECT * FROM contact_messages WHERE id = ?");
$stmt->execute([$msg_id]);
$contact_msg = $stmt->fetch();

if (!$contact_msg) {
    header('Location: ' . ADMIN_PATH . '/messages.php');
    exit;
}

// Durumu Okundu Olarak İşaretле
if ($contact_msg['status'] === 'new') {
    $stmt = $pdo->prepare("
        UPDATE contact_messages 
        SET status = 'read', read_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$msg_id]);
}

// Cevap Gönder
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reply_message = $_POST['reply_message'] ?? '';
    
    if (empty($reply_message)) {
        $error = 'Cevap mesajı boş olamaz.';
    } else {
        try {
            $stmt = $pdo->prepare("
                UPDATE contact_messages 
                SET reply_message = ?, status = 'replied', replied_by = ?, replied_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([
                $reply_message,
                $_SESSION['admin_id'],
                $msg_id
            ]);
            
            // Cevapı E-posta ile Gönder
            $settings = get_site_settings();
            
            $email_body = "
            <h2>Sorgunuza Cevap</h2>
            <p>Merhaba " . escape($contact_msg['name']) . ",</p>
            <p>Gönderdiğiniz mesaja cevap verilmiştir:</p>
            <hr>
            <p>" . nl2br(escape($reply_message)) . "</p>
            <hr>
            <p>Saygılarımızla,<br>" . escape($settings['site_name']) . "</p>
            ";
            
            send_email(
                $contact_msg['email'],
                "Re: " . $contact_msg['subject'],
                $email_body
            );
            
            $message = 'Cevap başarıyla gönderildi.';
            log_action('REPLY_MESSAGE', ['id' => $msg_id], 'success');
            
            // Sayfayı yenile
            header("Location: " . ADMIN_PATH . "/message-detail.php?id=$msg_id&success=1");
            exit;
            
        } catch (Exception $e) {
            $error = 'Hata: ' . $e->getMessage();
            log_action('REPLY_MESSAGE', ['id' => $msg_id], 'failed');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mesaj Detay - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Mesaj Detay</h1>
                <a href="<?php echo ADMIN_PATH; ?>/messages.php" class="btn btn-secondary">Geri Dön</a>
            </header>
            
            <div class="container-fluid">
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <!-- Mesaj Bilgileri -->
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo escape($contact_msg['subject']); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Ad:</strong> <?php echo escape($contact_msg['name']); ?></p>
                                <p><strong>E-posta:</strong> <a href="mailto:<?php echo escape($contact_msg['email']); ?>"><?php echo escape($contact_msg['email']); ?></a></p>
                                <p><strong>Telefon:</strong> <?php echo escape($contact_msg['phone'] ?? '-'); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Tarih:</strong> <?php echo date('d.m.Y H:i', strtotime($contact_msg['created_at'])); ?></p>
                                <p><strong>Durum:</strong> 
                                    <span class="badge badge-<?php 
                                        $status_colors = [
                                            'new' => 'danger',
                                            'read' => 'info',
                                            'replied' => 'success',
                                            'archived' => 'secondary'
                                        ];
                                        echo $status_colors[$contact_msg['status']] ?? 'secondary';
                                    ?>">
                                        <?php 
                                        $status_labels = [
                                            'new' => 'Yeni',
                                            'read' => 'Okundu',
                                            'replied' => 'Cevaplanmış',
                                            'archived' => 'Arşivlenmiş'
                                        ];
                                        echo $status_labels[$contact_msg['status']] ?? $contact_msg['status'];
                                        ?>
                                    </span>
                                </p>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h5>Mesaj:</h5>
                        <div class="message-content" style="background-color: #f9f9f9; padding: 15px; border-radius: 4px; margin-bottom: 2rem;">
                            <?php echo nl2br(escape($contact_msg['message'])); ?>
                        </div>
                        
                        <!-- Önceki Cevap -->
                        <?php if (!empty($contact_msg['reply_message'])): ?>
                            <h5>Cevap:</h5>
                            <div class="message-content" style="background-color: #e8f5e9; padding: 15px; border-radius: 4px; margin-bottom: 2rem;">
                                <?php echo nl2br(escape($contact_msg['reply_message'])); ?>
                            </div>
                            <p><small>Cevap veren: Admin | Tarih: <?php echo date('d.m.Y H:i', strtotime($contact_msg['replied_at'])); ?></small></p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Cevap Formu -->
                <?php if ($contact_msg['status'] !== 'archived'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Cevap Gönder</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group">
                                    <label for="reply_message">Cevap Mesajı *</label>
                                    <textarea id="reply_message" name="reply_message" required rows="6" class="form-control"></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Cevabı Gönder</button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>