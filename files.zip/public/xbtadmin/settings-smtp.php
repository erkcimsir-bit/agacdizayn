<?php
/**
 * XBT Yazılım Hizmetleri - SMTP E-posta Ayarları
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$settings = get_site_settings();

// SMTP Ayarlarını Güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $smtp_host = $_POST['smtp_host'] ?? '';
    $smtp_port = $_POST['smtp_port'] ?? 587;
    $smtp_username = $_POST['smtp_username'] ?? '';
    $smtp_password = $_POST['smtp_password'] ?? '';
    $smtp_from_email = $_POST['smtp_from_email'] ?? '';
    $whatsapp_number = $_POST['whatsapp_number'] ?? '';
    $whatsapp_enabled = isset($_POST['whatsapp_enabled']) ? 1 : 0;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE site_settings 
            SET smtp_host = ?,
                smtp_port = ?,
                smtp_username = ?,
                smtp_password = ?,
                smtp_from_email = ?,
                whatsapp_number = ?,
                whatsapp_enabled = ?
            WHERE id = 1
        ");
        $stmt->execute([
            $smtp_host,
            $smtp_port,
            $smtp_username,
            $smtp_password,
            $smtp_from_email,
            $whatsapp_number,
            $whatsapp_enabled
        ]);
        
        $message = 'SMTP ayarları başarıyla güncellendi.';
        $settings = get_site_settings();
        log_action('UPDATE_SMTP_SETTINGS', [], 'success');
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
        log_action('UPDATE_SMTP_SETTINGS', [], 'failed');
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMTP Ayarları - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>E-posta & WhatsApp Ayarları</h1>
            </header>
            
            <div class="container-fluid">
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5>SMTP E-posta Ayarları</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="smtp_host">SMTP Server *</label>
                                        <input type="text" id="smtp_host" name="smtp_host" 
                                               value="<?php echo escape($settings['smtp_host'] ?? ''); ?>" 
                                               placeholder="smtp.gmail.com" required class="form-control">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="smtp_port">Port *</label>
                                        <input type="number" id="smtp_port" name="smtp_port" 
                                               value="<?php echo escape($settings['smtp_port'] ?? '587'); ?>" 
                                               required class="form-control">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="smtp_username">Kullanıcı Adı (E-posta) *</label>
                                <input type="email" id="smtp_username" name="smtp_username" 
                                       value="<?php echo escape($settings['smtp_username'] ?? ''); ?>" 
                                       required class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="smtp_password">Şifre *</label>
                                <input type="password" id="smtp_password" name="smtp_password" 
                                       value="<?php echo escape($settings['smtp_password'] ?? ''); ?>" 
                                       required class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="smtp_from_email">Gönderen E-posta *</label>
                                <input type="email" id="smtp_from_email" name="smtp_from_email" 
                                       value="<?php echo escape($settings['smtp_from_email'] ?? ''); ?>" 
                                       required class="form-control">
                            </div>
                            
                            <hr>
                            
                            <div class="card-header">
                                <h5>WhatsApp Ayarları</h5>
                            </div>
                            
                            <div class="form-group">
                                <label for="whatsapp_number">WhatsApp Numarası</label>
                                <input type="text" id="whatsapp_number" name="whatsapp_number" 
                                       value="<?php echo escape($settings['whatsapp_number'] ?? ''); ?>" 
                                       placeholder="+90 555 555 55 55" class="form-control">
                                <small class="form-text text-muted">Örn: +90 (ülke kodu ile)</small>
                            </div>
                            
                            <div class="form-group form-check">
                                <input type="checkbox" id="whatsapp_enabled" name="whatsapp_enabled" 
                                       <?php echo ($settings['whatsapp_enabled'] ? 'checked' : ''); ?> 
                                       class="form-check-input">
                                <label for="whatsapp_enabled" class="form-check-label">
                                    WhatsApp butonunu aktifleştir
                                </label>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>