<?php
/**
 * XBT Yazılım Hizmetleri - Admin Dashboard
 */

session_start();
require_once '../../config/database.php';
require_once '../../config/config.php';
require_once '../../config/functions.php';

// Admin Kontrolü
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['two_factor_verified'])) {
    header('Location: auth.php');
    exit;
}

// Session Timeout
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > SESSION_TIMEOUT)) {
    session_destroy();
    header('Location: auth.php?expired=1');
    exit;
}

// İstatistikler
try {
    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM contact_messages WHERE status = 'new') as new_messages,
            (SELECT COUNT(*) FROM products) as total_products,
            (SELECT COUNT(*) FROM categories) as total_categories,
            (SELECT COUNT(DISTINCT ip_address) FROM visitor_analytics WHERE DATE(created_at) = CURDATE()) as today_visitors
    ");
    $stats = $stmt->fetch();
} catch (Exception $e) {
    $stats = ['new_messages' => 0, 'total_products' => 0, 'total_categories' => 0, 'today_visitors' => 0];
}

// Son Mesajlar
try {
    $stmt = $pdo->query("
        SELECT id, name, email, subject, created_at, status
        FROM contact_messages
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $recent_messages = $stmt->fetchAll();
} catch (Exception $e) {
    $recent_messages = [];
}

// Günlük Ziyaretçi Grafiği Verileri
try {
    $stmt = $pdo->query("
        SELECT 
            DATE(created_at) as date,
            COUNT(DISTINCT ip_address) as visitors
        FROM visitor_analytics
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ");
    $visitor_data = $stmt->fetchAll();
} catch (Exception $e) {
    $visitor_data = [];
}

// Veriyi JSON formatına çevir
$visitor_dates = json_encode(array_map(fn($v) => date('d.m', strtotime($v['date'])), $visitor_data));
$visitor_counts = json_encode(array_map(fn($v) => $v['visitors'], $visitor_data));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0"></script>
    <style>
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-icon {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
        }
        
        .stat-info h3 {
            font-size: 1.8rem;
            margin: 0;
            color: #333;
        }
        
        .stat-info p {
            margin: 0.3rem 0 0;
            color: #666;
            font-size: 0.9rem;
        }
        
        .chart-card {
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        
        .chart-card h3 {
            margin-top: 0;
            margin-bottom: 1.5rem;
        }
        
        .messages-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .messages-table table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .messages-table th {
            background: #f8f9fa;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 1px solid #dee2e6;
        }
        
        .messages-table td {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
        }
        
        .badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .badge-danger { background: #dc3545; color: white; }
        .badge-success { background: #28a745; color: white; }
        .badge-info { background: #17a2b8; color: white; }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        
        .btn-small:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div style="background: #f8f9fa; min-height: 100vh;">
        <!-- Top Bar -->
        <div style="background: white; padding: 1rem 2rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center;">
            <h1 style="margin: 0;">📊 Dashboard</h1>
            <div>
                <span style="margin-right: 1rem;">👤 <?php echo escape($_SESSION['admin_username']); ?></span>
                <a href="logout.php" style="padding: 0.5rem 1rem; background: #dc3545; color: white; text-decoration: none; border-radius: 4px;">Çıkış</a>
            </div>
        </div>
        
        <!-- İçerik -->
        <div style="padding: 2rem; max-width: 1200px; margin: 0 auto;">
            <!-- İstatistik Kartları -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                <div class="stat-card">
                    <div class="stat-icon" style="background: #e7f3ff;">📧</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['new_messages'] ?? 0; ?></h3>
                        <p>Yeni Mesaj</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: #f0e7ff;">📦</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total_products'] ?? 0; ?></h3>
                        <p>Toplam Ürün</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: #e7f9f5;">📂</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total_categories'] ?? 0; ?></h3>
                        <p>Toplam Kategori</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="background: #fff5e7;">👥</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['today_visitors'] ?? 0; ?></h3>
                        <p>Bugün Ziyaretçi</p>
                    </div>
                </div>
            </div>
            
            <!-- Grafikler -->
            <div style="display: grid; grid-template-columns: 1fr; gap: 2rem; margin-bottom: 2rem;">
                <div class="chart-card">
                    <h3>Son 30 Günün Ziyaretçileri</h3>
                    <canvas id="visitorChart"></canvas>
                </div>
            </div>
            
            <!-- Son Mesajlar -->
            <div style="margin-bottom: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h3>Son Mesajlar</h3>
                    <a href="messages.php" class="btn-small" style="background: #28a745;">Tümünü Gör</a>
                </div>
                
                <div class="messages-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Ad</th>
                                <th>E-posta</th>
                                <th>Konu</th>
                                <th>Tarih</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_messages)): ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 2rem;">Mesaj bulunamadı</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_messages as $msg): ?>
                                    <tr>
                                        <td><?php echo escape($msg['name']); ?></td>
                                        <td><?php echo escape($msg['email']); ?></td>
                                        <td><?php echo escape(substr($msg['subject'], 0, 30)); ?></td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($msg['created_at'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo ($msg['status'] === 'new' ? 'danger' : ($msg['status'] === 'replied' ? 'success' : 'info')); ?>">
                                                <?php 
                                                $labels = ['new' => 'Yeni', 'read' => 'Okundu', 'replied' => 'Cevaplanmış', 'archived' => 'Arşivlenmiş'];
                                                echo $labels[$msg['status']] ?? $msg['status'];
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="message-detail.php?id=<?php echo $msg['id']; ?>" class="btn-small">Cevapla</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Chart.js -->
    <script>
        const visitorDates = <?php echo $visitor_dates; ?>;
        const visitorCounts = <?php echo $visitor_counts; ?>;
        
        const ctx = document.getElementById('visitorChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: visitorDates,
                datasets: [{
                    label: 'Ziyaretçi Sayısı',
                    data: visitorCounts,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 4,
                    pointBackgroundColor: '#667eea'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>