<?php
/**
 * XBT Yazılım Hizmetleri - SEO Ayarları
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$settings = get_site_settings();

// SEO Ayarlarını Güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $google_verification = $_POST['google_verification'] ?? '';
    $google_analytics = $_POST['google_analytics'] ?? '';
    $google_recaptcha_key = $_POST['google_recaptcha_key'] ?? '';
    $google_recaptcha_secret = $_POST['google_recaptcha_secret'] ?? '';
    $google_maps_key = $_POST['google_maps_key'] ?? '';
    $ping_search_engines = isset($_POST['ping_search_engines']) ? 1 : 0;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE site_settings 
            SET google_verification = ?,
                google_analytics = ?,
                google_recaptcha_key = ?,
                google_recaptcha_secret = ?,
                google_maps_key = ?,
                ping_search_engines = ?
            WHERE id = 1
        ");
        $stmt->execute([
            $google_verification,
            $google_analytics,
            $google_recaptcha_key,
            $google_recaptcha_secret,
            $google_maps_key,
            $ping_search_engines
        ]);
        
        // Arama motorlarına ping at
        if ($ping_search_engines) {
            ping_search_engines(SITE_URL);
        }
        
        $message = 'SEO ayarları başarıyla güncellendi.';
        $settings = get_site_settings();
        log_action('UPDATE_SEO_SETTINGS', [], 'success');
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
        log_action('UPDATE_SEO_SETTINGS', [], 'failed');
    }
}

/**
 * Arama Motorlarına Ping At
 */
function ping_search_engines($site_url) {
    $urls = [
        'https://www.google.com/ping?sitemap=' . urlencode($site_url . '/sitemap.xml'),
        'https://www.bing.com/ping?sitemap=' . urlencode($site_url . '/sitemap.xml'),
    ];
    
    foreach ($urls as $url) {
        @file_get_contents($url);
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEO Ayarları - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>SEO & API Ayarları</h1>
            </header>
            
            <div class="container-fluid">
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header">
                        <h5>Google Hizmetleri</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="form-group">
                                <label for="google_verification">Google Site Doğrulama Kodu</label>
                                <input type="text" id="google_verification" name="google_verification" 
                                       value="<?php echo escape($settings['google_verification'] ?? ''); ?>" 
                                       placeholder="google-site-verification=xxxxx" class="form-control">
                                <small class="form-text text-muted">HTML meta etiketini yapıştırın</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="google_analytics">Google Analytics ID</label>
                                <input type="text" id="google_analytics" name="google_analytics" 
                                       value="<?php echo escape($settings['google_analytics'] ?? ''); ?>" 
                                       placeholder="G-XXXXXXXXXX" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="google_recaptcha_key">Google reCAPTCHA v3 - Site Anahtarı</label>
                                <input type="text" id="google_recaptcha_key" name="google_recaptcha_key" 
                                       value="<?php echo escape($settings['google_recaptcha_key'] ?? ''); ?>" 
                                       class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="google_recaptcha_secret">Google reCAPTCHA v3 - Gizli Anahtar</label>
                                <input type="password" id="google_recaptcha_secret" name="google_recaptcha_secret" 
                                       value="<?php echo escape($settings['google_recaptcha_secret'] ?? ''); ?>" 
                                       class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="google_maps_key">Google Maps API Anahtarı</label>
                                <input type="text" id="google_maps_key" name="google_maps_key" 
                                       value="<?php echo escape($settings['google_maps_key'] ?? ''); ?>" 
                                       class="form-control">
                            </div>
                            
                            <div class="form-group form-check">
                                <input type="checkbox" id="ping_search_engines" name="ping_search_engines" 
                                       <?php echo ($settings['ping_search_engines'] ? 'checked' : ''); ?> 
                                       class="form-check-input">
                                <label for="ping_search_engines" class="form-check-label">
                                    Arama motorlarına otomatik ping gönder
                                </label>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>