<?php
/**
 * XBT Yazılım Hizmetleri - Kategoriler Yönetimi
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$language_id = $_GET['lang'] ?? 1;

// Kategorileri Getir
$stmt = $pdo->prepare("
    SELECT c.*, l.code as lang_code, l.name as lang_name
    FROM categories c
    JOIN languages l ON c.language_id = l.id
    WHERE c.language_id = ?
    ORDER BY c.parent_id, c.sort_order
");
$stmt->execute([$language_id]);
$categories = $stmt->fetchAll();

// Dilleri Getir
$stmt = $pdo->query("SELECT id, code, name FROM languages WHERE active = 1");
$languages = $stmt->fetchAll();

// Kategori Ekle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $parent_id = !empty($_POST['parent_id']) ? $_POST['parent_id'] : null;
    
    try {
        // Slug oluştur
        $slug = create_slug($name);
        
        // Benzersizlik kontrolü
        $stmt = $pdo->prepare("
            SELECT id FROM categories 
            WHERE slug = ? AND language_id = ? LIMIT 1
        ");
        $stmt->execute([$slug, $language_id]);
        
        if ($stmt->fetch()) {
            $slug .= '-' . uniqid();
        }
        
        // Resim yükleme
        $image_path = null;
        if (!empty($_FILES['image']['tmp_name'])) {
            $result = upload_image($_FILES['image'], 'categories');
            if ($result['success']) {
                $image_path = $result['url'];
            }
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO categories (language_id, name, slug, description, image, parent_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $language_id,
            $name,
            $slug,
            $description,
            $image_path,
            $parent_id
        ]);
        
        $message = 'Kategori başarıyla eklendi.';
        log_action('ADD_CATEGORY', ['name' => $name], 'success');
        
        // Sayfayı yenile
        header("Location: " . ADMIN_PATH . "/categories.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
        log_action('ADD_CATEGORY', ['name' => $name], 'failed');
    }
}

// Kategori Sil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $cat_id = $_POST['cat_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ? AND language_id = ?");
        $stmt->execute([$cat_id, $language_id]);
        
        $message = 'Kategori başarıyla silindi.';
        log_action('DELETE_CATEGORY', ['id' => $cat_id], 'success');
        
        header("Location: " . ADMIN_PATH . "/categories.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategoriler - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Kategoriler Yönetimi</h1>
                <button class="btn btn-primary" data-toggle="modal" data-target="#addCategoryModal">
                    <i class="icon-plus"></i> Yeni Kategori
                </button>
            </header>
            
            <div class="container-fluid">
                <!-- Dil Seçimi -->
                <div class="form-group">
                    <label for="language_select">Dil Seçin:</label>
                    <select id="language_select" class="form-control" style="width: 200px;">
                        <?php foreach ($languages as $lang): ?>
                            <option value="<?php echo $lang['id']; ?>" 
                                    <?php echo ($lang['id'] == $language_id ? 'selected' : ''); ?>>
                                <?php echo escape($lang['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Adı</th>
                                <th>Slug</th>
                                <th>Üst Kategori</th>
                                <th>Resim</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $cat): ?>
                                <tr>
                                    <td><?php echo escape($cat['name']); ?></td>
                                    <td><code><?php echo escape($cat['slug']); ?></code></td>
                                    <td>
                                        <?php 
                                        if ($cat['parent_id']) {
                                            $parent = array_filter($categories, fn($c) => $c['id'] == $cat['parent_id']);
                                            if ($parent) {
                                                echo escape(reset($parent)['name']);
                                            }
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($cat['image']): ?>
                                            <img src="<?php echo escape($cat['image']); ?>" alt="<?php echo escape($cat['name']); ?>" style="max-width: 50px;">
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Yok</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo ($cat['active'] ? 'success' : 'danger'); ?>">
                                            <?php echo ($cat['active'] ? 'Aktif' : 'Pasif'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo ADMIN_PATH; ?>/category-edit.php?id=<?php echo $cat['id']; ?>" class="btn btn-primary btn-xs">Düzenle</a>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="cat_id" value="<?php echo $cat['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Emin misiniz?')">Sil</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal: Kategori Ekle -->
    <div class="modal" id="addCategoryModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Yeni Kategori Ekle</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="form-group">
                            <label for="name">Kategori Adı *</label>
                            <input type="text" id="name" name="name" required class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Açıklama</label>
                            <textarea id="description" name="description" rows="3" class="form-control"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="parent_id">Üst Kategori</label>
                            <select id="parent_id" name="parent_id" class="form-control">
                                <option value="">Ana Kategori</option>
                                <?php foreach ($categories as $cat): ?>
                                    <?php if (!$cat['parent_id']): ?>
                                        <option value="<?php echo $cat['id']; ?>">
                                            <?php echo escape($cat['name']); ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="image">Resim</label>
                            <input type="file" id="image" name="image" accept="image/*" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Ekle</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('language_select').addEventListener('change', function() {
            window.location.href = '<?php echo ADMIN_PATH; ?>/categories.php?lang=' + this.value;
        });
    </script>
</body>
</html>