<?php
/**
 * XBT Yazılım Hizmetleri - İletişim Mesajları Yönetimi
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$filter = $_GET['filter'] ?? 'all';
$page = $_GET['page'] ?? 1;
$per_page = 15;

// Sorguyu oluştur
$where = '';
if ($filter !== 'all') {
    $where = "WHERE status = '" . $filter . "'";
}

// Toplam sayı
$stmt = $pdo->query("SELECT COUNT(*) as total FROM contact_messages $where");
$total = $stmt->fetch()['total'];

$pagination = paginate($total, $per_page, $page);
$offset = $pagination['offset'];

// Mesajları Getir
$stmt = $pdo->query("
    SELECT * FROM contact_messages
    $where
    ORDER BY created_at DESC
    LIMIT $per_page OFFSET $offset
");
$messages = $stmt->fetchAll();

// Yeni Mesaj Sayısı
$stmt = $pdo->query("SELECT COUNT(*) as total FROM contact_messages WHERE status = 'new'");
$new_count = $stmt->fetch()['total'];

// Durumu Güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $msg_id = $_POST['msg_id'] ?? 0;
    $status = $_POST['status'] ?? 'read';
    
    try {
        $stmt = $pdo->prepare("
            UPDATE contact_messages 
            SET status = ?, read_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$status, $msg_id]);
        
        log_action('UPDATE_MESSAGE_STATUS', ['id' => $msg_id, 'status' => $status], 'success');
        
        header("Location: " . ADMIN_PATH . "/messages.php?filter=$filter&page=$page&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}

// Mesajı Sil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $msg_id = $_POST['msg_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
        $stmt->execute([$msg_id]);
        
        $message = 'Mesaj başarıyla silindi.';
        log_action('DELETE_MESSAGE', ['id' => $msg_id], 'success');
        
        header("Location: " . ADMIN_PATH . "/messages.php?filter=$filter&page=$page&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mesajlar - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>
                    İletişim Mesajları
                    <?php if ($new_count > 0): ?>
                        <span class="badge badge-danger"><?php echo $new_count; ?></span>
                    <?php endif; ?>
                </h1>
            </header>
            
            <div class="container-fluid">
                <!-- Filtreler -->
                <div class="filter-tabs">
                    <a href="?filter=all" class="btn <?php echo ($filter === 'all' ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                        Tümü (<?php echo $total; ?>)
                    </a>
                    <a href="?filter=new" class="btn <?php echo ($filter === 'new' ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                        Yeni (<?php $stmt = $pdo->query("SELECT COUNT(*) as c FROM contact_messages WHERE status='new'"); echo $stmt->fetch()['c']; ?>)
                    </a>
                    <a href="?filter=read" class="btn <?php echo ($filter === 'read' ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                        Okundu
                    </a>
                    <a href="?filter=replied" class="btn <?php echo ($filter === 'replied' ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                        Cevaplanmış
                    </a>
                    <a href="?filter=archived" class="btn <?php echo ($filter === 'archived' ? 'btn-primary' : 'btn-secondary'); ?> btn-sm">
                        Arşivlenmiş
                    </a>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Ad</th>
                                <th>E-posta</th>
                                <th>Konu</th>
                                <th>Tarih</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($messages)): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Mesaj bulunamadı.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($messages as $msg): ?>
                                    <tr class="<?php echo ($msg['status'] === 'new' ? 'table-warning' : ''); ?>">
                                        <td><?php echo escape($msg['name']); ?></td>
                                        <td><a href="mailto:<?php echo escape($msg['email']); ?>"><?php echo escape($msg['email']); ?></a></td>
                                        <td><?php echo escape(substr($msg['subject'], 0, 50)); ?></td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($msg['created_at'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php 
                                                $status_colors = [
                                                    'new' => 'danger',
                                                    'read' => 'info',
                                                    'replied' => 'success',
                                                    'archived' => 'secondary'
                                                ];
                                                echo $status_colors[$msg['status']] ?? 'secondary';
                                            ?>">
                                                <?php 
                                                $status_labels = [
                                                    'new' => 'Yeni',
                                                    'read' => 'Okundu',
                                                    'replied' => 'Cevaplanmış',
                                                    'archived' => 'Arşivlenmiş'
                                                ];
                                                echo $status_labels[$msg['status']] ?? $msg['status'];
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo ADMIN_PATH; ?>/message-detail.php?id=<?php echo $msg['id']; ?>" class="btn btn-primary btn-xs">Görüntüle</a>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="msg_id" value="<?php echo $msg['id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Emin misiniz?')">Sil</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Sayfalama -->
                <div class="pagination">
                    <?php if ($pagination['has_prev']): ?>
                        <a href="?filter=<?php echo $filter; ?>&page=1" class="btn btn-secondary btn-sm">İlk</a>
                        <a href="?filter=<?php echo $filter; ?>&page=<?php echo $pagination['current_page'] - 1; ?>" class="btn btn-secondary btn-sm">Önceki</a>
                    <?php endif; ?>
                    
                    <span class="pagination-info">
                        Sayfa <?php echo $pagination['current_page']; ?> / <?php echo $pagination['total_pages']; ?>
                    </span>
                    
                    <?php if ($pagination['has_next']): ?>
                        <a href="?filter=<?php echo $filter; ?>&page=<?php echo $pagination['current_page'] + 1; ?>" class="btn btn-secondary btn-sm">Sonraki</a>
                        <a href="?filter=<?php echo $filter; ?>&page=<?php echo $pagination['total_pages']; ?>" class="btn btn-secondary btn-sm">Son</a>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>