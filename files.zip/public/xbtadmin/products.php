<?php
/**
 * XBT Yazılım Hizmetleri - Ürünler Yönetimi
 */

session_start();
require_once '../../config/config.php';
require_once '../../config/database.php';
require_once '../../config/functions.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . ADMIN_PATH . '/auth.php');
    exit;
}

$message = '';
$error = '';
$language_id = $_GET['lang'] ?? 1;
$page = $_GET['page'] ?? 1;
$per_page = 10;

// Ürünleri Getir
$stmt = $pdo->prepare("
    SELECT COUNT(*) as total FROM products WHERE language_id = ?
");
$stmt->execute([$language_id]);
$total = $stmt->fetch()['total'];

$pagination = paginate($total, $per_page, $page);
$offset = $pagination['offset'];

$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.language_id = ?
    ORDER BY p.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$language_id, $per_page, $offset]);
$products = $stmt->fetchAll();

// Kategorileri Getir
$stmt = $pdo->prepare("
    SELECT id, name FROM categories WHERE language_id = ? AND active = 1
");
$stmt->fetchAll($language_id);
$categories = $stmt->fetchAll();

// Dilleri Getir
$stmt = $pdo->query("SELECT id, code, name FROM languages WHERE active = 1");
$languages = $stmt->fetchAll();

// Ürün Ekle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = $_POST['name'] ?? '';
    $category_id = $_POST['category_id'] ?? 0;
    $description = $_POST['description'] ?? '';
    $short_description = $_POST['short_description'] ?? '';
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    try {
        $slug = create_slug($name);
        
        // Benzersizlik kontrolü
        $stmt = $pdo->prepare("
            SELECT id FROM products 
            WHERE slug = ? AND language_id = ? LIMIT 1
        ");
        $stmt->execute([$slug, $language_id]);
        
        if ($stmt->fetch()) {
            $slug .= '-' . uniqid();
        }
        
        // Resim yükleme
        $image_path = null;
        if (!empty($_FILES['image']['tmp_name'])) {
            $result = upload_image($_FILES['image'], 'products');
            if ($result['success']) {
                $image_path = $result['url'];
            }
        }
        
        // Meta bilgileri
        $meta_description = $_POST['meta_description'] ?? '';
        $meta_keywords = $_POST['meta_keywords'] ?? '';
        
        $stmt = $pdo->prepare("
            INSERT INTO products (language_id, category_id, name, slug, description, short_description, image, meta_description, meta_keywords, featured)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $language_id,
            $category_id,
            $name,
            $slug,
            $description,
            $short_description,
            $image_path,
            $meta_description,
            $meta_keywords,
            $featured
        ]);
        
        $message = 'Ürün başarıyla eklendi.';
        log_action('ADD_PRODUCT', ['name' => $name], 'success');
        
        header("Location: " . ADMIN_PATH . "/products.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
        log_action('ADD_PRODUCT', ['name' => $name], 'failed');
    }
}

// Ürün Sil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $prod_id = $_POST['prod_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ? AND language_id = ?");
        $stmt->execute([$prod_id, $language_id]);
        
        $message = 'Ürün başarıyla silindi.';
        log_action('DELETE_PRODUCT', ['id' => $prod_id], 'success');
        
        header("Location: " . ADMIN_PATH . "/products.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}

// Öne Çıkan Durumunu Değiştir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_featured') {
    $prod_id = $_POST['prod_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE products 
            SET featured = IF(featured = 1, 0, 1)
            WHERE id = ? AND language_id = ?
        ");
        $stmt->execute([$prod_id, $language_id]);
        
        log_action('TOGGLE_FEATURED_PRODUCT', ['id' => $prod_id], 'success');
        
        header("Location: " . ADMIN_PATH . "/products.php?lang=$language_id&success=1");
        exit;
        
    } catch (Exception $e) {
        $error = 'Hata: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürünler - Admin Panel</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Ürünler Yönetimi</h1>
                <button class="btn btn-primary" data-toggle="modal" data-target="#addProductModal">
                    <i class="icon-plus"></i> Yeni Ürün
                </button>
            </header>
            
            <div class="container-fluid">
                <!-- Dil Seçimi -->
                <div class="form-group">
                    <label for="language_select">Dil Seçin:</label>
                    <select id="language_select" class="form-control" style="width: 200px;">
                        <?php foreach ($languages as $lang): ?>
                            <option value="<?php echo $lang['id']; ?>" 
                                    <?php echo ($lang['id'] == $language_id ? 'selected' : ''); ?>>
                                <?php echo escape($lang['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Resim</th>
                                <th>Adı</th>
                                <th>Kategori</th>
                                <th>Slug</th>
                                <th>Öne Çıkan</th>
                                <th>Durum</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $prod): ?>
                                <tr>
                                    <td>
                                        <?php if ($prod['image']): ?>
                                            <img src="<?php echo escape($prod['image']); ?>" alt="<?php echo escape($prod['name']); ?>" style="max-width: 50px; max-height: 50px;">
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Yok</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo escape($prod['name']); ?></td>
                                    <td><?php echo escape($prod['category_name'] ?? '-'); ?></td>
                                    <td><code><?php echo escape($prod['slug']); ?></code></td>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="toggle_featured">
                                            <input type="hidden" name="prod_id" value="<?php echo $prod['id']; ?>">
                                            <button type="submit" class="badge badge-<?php echo ($prod['featured'] ? 'success' : 'secondary'); ?>" style="border: none; cursor: pointer;">
                                                <?php echo ($prod['featured'] ? 'Evet' : 'Hayır'); ?>
                                            </button>
                                        </form>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo ($prod['active'] ? 'success' : 'danger'); ?>">
                                            <?php echo ($prod['active'] ? 'Aktif' : 'Pasif'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo ADMIN_PATH; ?>/product-edit.php?id=<?php echo $prod['id']; ?>" class="btn btn-primary btn-xs">Düzenle</a>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="prod_id" value="<?php echo $prod['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Emin misiniz?')">Sil</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Sayfalama -->
                <div class="pagination">
                    <?php if ($pagination['has_prev']): ?>
                        <a href="?lang=<?php echo $language_id; ?>&page=1" class="btn btn-secondary btn-sm">İlk</a>
                        <a href="?lang=<?php echo $language_id; ?>&page=<?php echo $pagination['current_page'] - 1; ?>" class="btn btn-secondary btn-sm">Önceki</a>
                    <?php endif; ?>
                    
                    <span class="pagination-info">
                        Sayfa <?php echo $pagination['current_page']; ?> / <?php echo $pagination['total_pages']; ?>
                    </span>
                    
                    <?php if ($pagination['has_next']): ?>
                        <a href="?lang=<?php echo $language_id; ?>&page=<?php echo $pagination['current_page'] + 1; ?>" class="btn btn-secondary btn-sm">Sonraki</a>
                        <a href="?lang=<?php echo $language_id; ?>&page=<?php echo $pagination['total_pages']; ?>" class="btn btn-secondary btn-sm">Son</a>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal: Ürün Ekle -->
    <div class="modal" id="addProductModal">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Yeni Ürün Ekle</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="form-group">
                            <label for="name">Ürün Adı *</label>
                            <input type="text" id="name" name="name" required class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="category_id">Kategori *</label>
                            <select id="category_id" name="category_id" required class="form-control">
                                <option value="">Kategori Seçin</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>">
                                        <?php echo escape($cat['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="short_description">Kısa Açıklama</label>
                            <textarea id="short_description" name="short_description" rows="2" class="form-control"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Detaylı Açıklama</label>
                            <textarea id="description" name="description" rows="4" class="form-control"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="meta_description">Meta Açıklaması (SEO)</label>
                            <textarea id="meta_description" name="meta_description" rows="2" class="form-control" placeholder="160 karakter kadar"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="meta_keywords">Meta Anahtar Kelimeler (virgülle ayırın)</label>
                            <input type="text" id="meta_keywords" name="meta_keywords" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="image">Ürün Resmi</label>
                            <input type="file" id="image" name="image" accept="image/*" class="form-control">
                        </div>
                        
                        <div class="form-group form-check">
                            <input type="checkbox" id="featured" name="featured" class="form-check-input">
                            <label for="featured" class="form-check-label">
                                Öne Çıkart
                            </label>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Ekle</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('language_select').addEventListener('change', function() {
            window.location.href = '<?php echo ADMIN_PATH; ?>/products.php?lang=' + this.value;
        });
        
        // Modal açma/kapama
        document.querySelectorAll('[data-toggle="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                document.querySelector(targetId).classList.add('show');
            });
        });
        
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                this.closest('.modal').classList.remove('show');
            });
        });
    </script>
</body>
</html>