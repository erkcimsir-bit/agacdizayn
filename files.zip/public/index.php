<?php
/**
 * XBT Yazılım Hizmetleri - Ana Sayfa
 */

session_start();
require_once '../config/database.php';
require_once '../config/config.php';
require_once '../config/functions.php';

// Bakım Modu Kontrolü
$settings = get_site_settings();
if ($settings && $settings['maintenance_mode']) {
    header('HTTP/1.1 503 Service Unavailable');
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Site Bakımda</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: Arial, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .container { text-align: center; background: white; padding: 40px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); max-width: 500px; }
            h1 { color: #333; margin-bottom: 10px; font-size: 2.5rem; }
            p { color: #666; font-size: 1.1rem; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔧 Bakımda</h1>
            <p><?php echo escape($settings['maintenance_message'] ?? 'Sitemiz bakım için kapalıdır. Lütfen daha sonra ziyaret edin.'); ?></p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// IP Engeli Kontrolü
if (is_ip_blocked()) {
    http_response_code(403);
    die('Erişim Engellendi');
}

// Ziyaretçi Kaydı
log_visitor();

// Dil Seçimi
$lang = $_GET['lang'] ?? $_SESSION['lang'] ?? 'tr';
$_SESSION['lang'] = $lang;

$stmt = $pdo->prepare("SELECT id FROM languages WHERE code = ? AND active = 1 LIMIT 1");
$stmt->execute([$lang]);
$language = $stmt->fetch();
$language_id = $language['id'] ?? 1;

// Sliders
$stmt = $pdo->prepare("
    SELECT * FROM sliders 
    WHERE language_id = ? AND active = 1
    ORDER BY sort_order
");
$stmt->execute([$language_id]);
$sliders = $stmt->fetchAll();

// Ana Kategoriler
$stmt = $pdo->prepare("
    SELECT id, name, slug, image FROM categories 
    WHERE language_id = ? AND parent_id IS NULL AND active = 1
    ORDER BY sort_order
");
$stmt->execute([$language_id]);
$categories = $stmt->fetchAll();

// Öne Çıkan Ürünler
$stmt = $pdo->prepare("
    SELECT id, name, slug, short_description, image FROM products 
    WHERE language_id = ? AND featured = 1 AND active = 1
    LIMIT 8
");
$stmt->execute([$language_id]);
$featured_products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XBT Yazılım Hizmetleri - Profesyonel Yazılım Çözümleri</title>
    <meta name="description" content="<?php echo escape($settings['site_description'] ?? ''); ?>">
    <meta name="keywords" content="<?php echo escape($settings['site_keywords'] ?? ''); ?>">
    <meta property="og:title" content="XBT Yazılım Hizmetleri">
    <meta property="og:description" content="<?php echo escape($settings['site_description'] ?? ''); ?>">
    <?php if (!empty($settings['favicon_path'])): ?>
        <link rel="icon" href="<?php echo escape($settings['favicon_path']); ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo SITE_URL; ?>">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    <?php if (!empty($settings['google_verification'])): ?>
        <meta name="google-site-verification" content="<?php echo escape($settings['google_verification']); ?>">
    <?php endif; ?>
</head>
<body>
    <!-- Header & Navigation -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Hero Slider -->
    <?php if (!empty($sliders)): ?>
    <section class="hero-slider">
        <div class="slider-container">
            <?php foreach ($sliders as $index => $slider): ?>
                <div class="slide <?php echo ($index === 0 ? 'active' : ''); ?>" style="background-image: url('<?php echo escape($slider['image']); ?>');">
                    <div class="slide-overlay"></div>
                    <div class="slide-content">
                        <div class="container">
                            <h1 class="slide-title"><?php echo escape($slider['title']); ?></h1>
                            <p class="slide-description"><?php echo escape($slider['description']); ?></p>
                            <?php if (!empty($slider['link'])): ?>
                                <a href="<?php echo safe_url($slider['link']); ?>" class="btn btn-primary btn-lg">
                                    <?php echo escape($slider['button_text'] ?? 'Daha Fazla'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Slider Kontrolleeri -->
        <div class="slider-controls">
            <button class="slider-prev" onclick="prevSlide()">❮</button>
            <button class="slider-next" onclick="nextSlide()">❯</button>
        </div>
        
        <!-- Slider İndikatörleri -->
        <div class="slider-dots">
            <?php foreach ($sliders as $index => $slider): ?>
                <button class="dot <?php echo ($index === 0 ? 'active' : ''); ?>" onclick="currentSlide(<?php echo $index; ?>)"></button>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Kategoriler Bölümü -->
    <?php if (!empty($categories)): ?>
    <section class="categories-section">
        <div class="container">
            <h2 class="section-title">Ürün Kategorilerimiz</h2>
            <div class="categories-grid">
                <?php foreach ($categories as $cat): ?>
                    <div class="category-card">
                        <?php if (!empty($cat['image'])): ?>
                            <img src="<?php echo escape($cat['image']); ?>" alt="<?php echo escape($cat['name']); ?>" class="category-image">
                        <?php endif; ?>
                        <h3><?php echo escape($cat['name']); ?></h3>
                        <a href="<?php echo SITE_URL; ?>/products.php?cat=<?php echo escape($cat['slug']); ?>" class="btn btn-outline">Görüntüle</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Öne Çıkan Ürünler -->
    <?php if (!empty($featured_products)): ?>
    <section class="featured-products">
        <div class="container">
            <h2 class="section-title">Öne Çıkan Ürünler</h2>
            <div class="products-grid">
                <?php foreach ($featured_products as $product): ?>
                    <div class="product-card">
                        <?php if (!empty($product['image'])): ?>
                            <img src="<?php echo escape($product['image']); ?>" alt="<?php echo escape($product['name']); ?>" class="product-image">
                        <?php endif; ?>
                        <div class="product-content">
                            <h3><?php echo escape($product['name']); ?></h3>
                            <p><?php echo escape(substr($product['short_description'] ?? '', 0, 100)); ?>...</p>
                            <a href="<?php echo SITE_URL; ?>/product.php?id=<?php echo escape($product['slug']); ?>" class="btn btn-primary">Detaylar</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Google Analytics -->
    <?php if (!empty($settings['google_analytics'])): ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo escape($settings['google_analytics']); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '<?php echo escape($settings['google_analytics']); ?>');
        </script>
    <?php endif; ?>
    
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>