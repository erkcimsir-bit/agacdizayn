<?php
/**
 * XBT Yazılım Hizmetleri - İletişim Sayfası
 */

session_start();
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/functions.php';

// Bakım Modu Kontrolü
$settings = get_site_settings();
if ($settings['maintenance_mode'] && !isset($_SESSION['admin_id'])) {
    header('Location: ' . SITE_URL);
    exit;
}

$message = '';
$error = '';
$language_id = $_SESSION['language_id'] ?? 1;

// reCAPTCHA Doğrulaması
function verify_recaptcha($token) {
    global $settings;
    
    if (empty($settings['google_recaptcha_secret'])) {
        return true; // Ayarlanmadıysa geç
    }
    
    $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'secret' => $settings['google_recaptcha_secret'],
        'response' => $token
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    return ($response['success'] ?? false) && ($response['score'] ?? 0) > 0.5;
}

// Form Gönderimi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message_text = $_POST['message'] ?? '';
    $recaptcha_token = $_POST['g-recaptcha-response'] ?? '';
    
    // Validasyon
    $errors = [];
    
    if (empty($name)) $errors[] = 'Ad alanı gereklidir.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Geçerli bir e-posta adresi gereklidir.';
    if (empty($subject)) $errors[] = 'Konu alanı gereklidir.';
    if (empty($message_text)) $errors[] = 'Mesaj alanı gereklidir.';
    if (strlen($message_text) < 10) $errors[] = 'Mesaj en az 10 karakter olmalıdır.';
    
    // reCAPTCHA Doğrulaması
    if (!verify_recaptcha($recaptcha_token)) {
        $errors[] = 'reCAPTCHA doğrulaması başarısız. Lütfen tekrar deneyin.';
    }
    
    if (empty($errors)) {
        try {
            // Mesajı Kaydet
            $stmt = $pdo->prepare("
                INSERT INTO contact_messages (language_id, name, email, phone, subject, message, status)
                VALUES (?, ?, ?, ?, ?, ?, 'new')
            ");
            $stmt->execute([
                $language_id,
                $name,
                $email,
                $phone ?: null,
                $subject,
                $message_text
            ]);
            
            // E-posta Gönder - Admin'e
            $admin_message = "
            <h2>Yeni İletişim Formu Mesajı</h2>
            <p><strong>Ad:</strong> $name</p>
            <p><strong>E-posta:</strong> $email</p>
            <p><strong>Telefon:</strong> $phone</p>
            <p><strong>Konu:</strong> $subject</p>
            <p><strong>Mesaj:</strong></p>
            <p>" . nl2br($message_text) . "</p>
            <hr>
            <p><a href='" . SITE_URL . ADMIN_PATH . "/messages.php'>Mesajları Görüntüle</a></p>
            ";
            
            send_email(
                $settings['smtp_from_email'],
                "[YENİ MESAJ] " . $subject,
                $admin_message
            );
            
            // E-posta Gönder - Kullanıcıya
            $user_message = "
            <h2>Mesajınız Alındı</h2>
            <p>Merhaba $name,</p>
            <p>İletişim formunuz aracılığıyla gönderdiğiniz mesaj başarıyla alınmıştır.</p>
            <p>En kısa sürede size geri dönüş yapılacaktır.</p>
            <p>Saygılarımızla,<br>XBT Yazılım Hizmetleri</p>
            ";
            
            send_email(
                $email,
                "Mesajınız Alındı",
                $user_message
            );
            
            $message = 'Mesajınız başarıyla gönderildi. En kısa sürede sizinle iletişime geçeceğiz.';
            
        } catch (Exception $e) {
            $error = 'Bir hata oluştu. Lütfen daha sonra tekrar deneyin.';
            error_log("İletişim formu hatası: " . $e->getMessage());
        }
    } else {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İletişim - XBT Yazılım Hizmetleri</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- İletişim Formu -->
    <section class="contact-section">
        <div class="container">
            <h1>İletişim</h1>
            <p class="lead">Sorularınız ve önerileriniz için bizimle iletişime geçin.</p>
            
            <div class="contact-grid">
                <!-- Form -->
                <div class="contact-form-wrapper">
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-success"><?php echo $message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" class="contact-form">
                        <div class="form-group">
                            <label for="name">Adınız *</label>
                            <input type="text" id="name" name="name" required class="form-control" 
                                   value="<?php echo escape($_POST['name'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email">E-posta Adresiniz *</label>
                            <input type="email" id="email" name="email" required class="form-control"
                                   value="<?php echo escape($_POST['email'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Telefon Numaranız</label>
                            <input type="tel" id="phone" name="phone" class="form-control"
                                   value="<?php echo escape($_POST['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="subject">Konu *</label>
                            <input type="text" id="subject" name="subject" required class="form-control"
                                   value="<?php echo escape($_POST['subject'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="message">Mesajınız *</label>
                            <textarea id="message" name="message" required rows="6" class="form-control"><?php echo escape($_POST['message'] ?? ''); ?></textarea>
                        </div>
                        
                        <!-- reCAPTCHA -->
                        <?php if (!empty($settings['google_recaptcha_key'])): ?>
                            <div class="g-recaptcha" data-sitekey="<?php echo escape($settings['google_recaptcha_key']); ?>" data-action="contact"></div>
                        <?php endif; ?>
                        
                        <button type="submit" class="btn btn-primary btn-lg">Gönder</button>
                    </form>
                </div>
                
                <!-- İletişim Bilgileri -->
                <div class="contact-info">
                    <h3>İletişim Bilgileri</h3>
                    
                    <?php if (!empty($settings['whatsapp_enabled']) && !empty($settings['whatsapp_number'])): ?>
                        <div class="contact-item">
                            <h4>WhatsApp</h4>
                            <a href="https://wa.me/<?php echo str_replace([' ', '-', '(', ')'], '', $settings['whatsapp_number']); ?>" 
                               target="_blank" class="btn btn-success">
                                <i class="icon-whatsapp"></i> WhatsApp
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="contact-item">
                        <h4>E-posta</h4>
                        <a href="mailto:<?php echo escape($settings['smtp_from_email']); ?>">
                            <?php echo escape($settings['smtp_from_email']); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    
    <?php if (!empty($settings['google_recaptcha_key'])): ?>
        <script src="https://www.google.com/recaptcha/api.js?render=<?php echo escape($settings['google_recaptcha_key']); ?>"></script>
    <?php endif; ?>
    
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>