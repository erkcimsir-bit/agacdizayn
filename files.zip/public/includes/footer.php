<?php
/**
 * Ağaç Dizayn - Footer
 */

$settings = get_site_settings();
$current_year = date('Y');
?>
<footer class="footer" style="background: #2c3e50; color: white; padding: 3rem 0 1rem;">
    <div class="footer-content">
        <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 15px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 2rem;">
                <!-- Şirket Bilgisi -->
                <div class="footer-section">
                    <h4 style="color: white; margin-bottom: 1rem;">🌲 <?php echo escape($settings['site_name']); ?></h4>
                    <p style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">
                        <?php echo escape($settings['site_description'] ?? 'Profesyonel ağaç tasarım ve dekorasyon hizmetleri sunuyoruz.'); ?>
                    </p>
                </div>
                
                <!-- Hızlı Bağlantılar -->
                <div class="footer-section">
                    <h4 style="color: white; margin-bottom: 1rem;">Hızlı Bağlantılar</h4>
                    <ul style="list-style: none; padding: 0;">
                        <li style="margin-bottom: 0.5rem;"><a href="<?php echo SITE_URL; ?>" style="color: rgba(255,255,255,0.7); text-decoration: none;">Anasayfa</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="<?php echo SITE_URL; ?>/products.php" style="color: rgba(255,255,255,0.7); text-decoration: none;">Hizmetler</a></li>
                        <li style="margin-bottom: 0.5rem;"><a href="<?php echo SITE_URL; ?>/contact.php" style="color: rgba(255,255,255,0.7); text-decoration: none;">İletişim</a></li>
                    </ul>
                </div>
                
                <!-- İletişim -->
                <div class="footer-section">
                    <h4 style="color: white; margin-bottom: 1rem;">İletişim</h4>
                    <ul style="list-style: none; padding: 0;">
                        <li style="margin-bottom: 0.5rem;">
                            <a href="mailto:<?php echo escape($settings['smtp_from_email']); ?>" style="color: rgba(255,255,255,0.7); text-decoration: none;">
                                📧 <?php echo escape($settings['smtp_from_email']); ?>
                            </a>
                        </li>
                        <?php if (!empty($settings['whatsapp_enabled']) && !empty($settings['whatsapp_number'])): ?>
                            <li style="margin-bottom: 0.5rem;">
                                <a href="https://wa.me/<?php echo str_replace([' ', '-', '(', ')'], '', $settings['whatsapp_number']); ?>" target="_blank" style="color: rgba(255,255,255,0.7); text-decoration: none;">
                                    💬 WhatsApp
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom" style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1.5rem;">
        <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 15px; text-align: center;">
            <p style="margin: 0; color: rgba(255,255,255,0.7); font-size: 0.9rem;">
                &copy; <?php echo $current_year; ?> <?php echo escape($settings['site_name']); ?>. Tüm Hakları Saklıdır.
            </p>
        </div>
    </div>
</footer>