<?php
/**
 * Ağaç Dizayn - Başlık ve Navigasyon
 */

$settings = get_site_settings();
$current_lang = $_SESSION['lang'] ?? 'tr';

// Dilleri getir
$stmt = $pdo->query("SELECT id, code, name FROM languages WHERE active = 1");
$languages = $stmt->fetchAll();

// Menüleri getir
$stmt = $pdo->prepare("
    SELECT id, title, slug, parent_id 
    FROM menus 
    WHERE language_id = (SELECT id FROM languages WHERE code = ?) AND active = 1
    ORDER BY parent_id, sort_order
");
$stmt->execute([$current_lang]);
$menu_items = $stmt->fetchAll();
?>
<header class="header">
    <nav class="navbar" style="background: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 1rem 0;">
        <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 15px; display: flex; justify-content: space-between; align-items: center;">
            <!-- Logo -->
            <div class="navbar-brand" style="display: flex; align-items: center;">
                <?php if (!empty($settings['logo_path'])): ?>
                    <a href="<?php echo SITE_URL; ?>" style="text-decoration: none;">
                        <img src="<?php echo escape($settings['logo_path']); ?>" alt="<?php echo escape($settings['site_name']); ?>" style="max-height: 50px; width: auto;">
                    </a>
                <?php else: ?>
                    <a href="<?php echo SITE_URL; ?>" style="text-decoration: none; color: #333; font-weight: 600; font-size: 1.3rem;">
                        🌲 Ağaç Dizayn
                    </a>
                <?php endif; ?>
            </div>
            
            <!-- Menu -->
            <ul class="navbar-menu" style="list-style: none; display: flex; gap: 2rem; margin: 0; padding: 0;">
                <li><a href="<?php echo SITE_URL; ?>" style="text-decoration: none; color: #333; font-weight: 500;">Anasayfa</a></li>
                <li><a href="<?php echo SITE_URL; ?>/products.php" style="text-decoration: none; color: #333; font-weight: 500;">Hizmetler</a></li>
                <li><a href="<?php echo SITE_URL; ?>/contact.php" style="text-decoration: none; color: #333; font-weight: 500;">İletişim</a></li>
            </ul>
            
            <!-- Sağ Taraf -->
            <div class="navbar-right" style="display: flex; align-items: center; gap: 1rem;">
                <!-- Dil Seçimi -->
                <select id="lang-select" class="lang-select" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 4px; cursor: pointer;">
                    <?php foreach ($languages as $lang): ?>
                        <option value="<?php echo $lang['code']; ?>" <?php echo ($lang['code'] === $current_lang ? 'selected' : ''); ?>>
                            <?php echo escape($lang['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <!-- WhatsApp -->
                <?php if (!empty($settings['whatsapp_enabled']) && !empty($settings['whatsapp_number'])): ?>
                    <a href="https://wa.me/<?php echo str_replace([' ', '-', '(', ')'], '', $settings['whatsapp_number']); ?>" 
                       target="_blank" style="width: 40px; height: 40px; background: #25D366; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; text-decoration: none;" title="WhatsApp">
                        💬
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header>

<script>
document.getElementById('lang-select')?.addEventListener('change', function() {
    const currentUrl = window.location.href;
    const newUrl = currentUrl.includes('?') 
        ? currentUrl + '&lang=' + this.value 
        : currentUrl + '?lang=' + this.value;
    window.location.href = newUrl;
});
</script>