<?php
/**
 * XBT Yazılım Hizmetleri - Yardımcı Fonksiyonlar
 */

/**
 * Güvenli çıkış (XSS Koruması)
 */
function escape($data) {
    if (is_array($data)) {
        return array_map('escape', $data);
    }
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * Güvenli URL
 */
function safe_url($url) {
    return filter_var($url, FILTER_SANITIZE_URL);
}

/**
 * Slug Oluştur
 */
function create_slug($text) {
    $text = mb_strtolower(trim($text), 'UTF-8');
    $text = preg_replace('/[^\p{L}\p{N}\s-]/u', '', $text);
    $text = preg_replace('/[-\s]+/', '-', $text);
    return trim($text, '-');
}

/**
 * Site Ayarlarını Getir
 */
function get_site_settings() {
    global $pdo;
    static $settings = null;
    
    if ($settings === null) {
        try {
            $stmt = $pdo->query("SELECT * FROM site_settings LIMIT 1");
            $settings = $stmt->fetch();
        } catch (Exception $e) {
            $settings = [];
        }
    }
    
    return $settings ?? [];
}

/**
 * Log Kaydı
 */
function log_action($action, $details = [], $status = 'success') {
    global $pdo;
    
    $admin_id = $_SESSION['admin_id'] ?? null;
    $ip = get_client_ip();
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO security_logs (admin_id, action, details, ip_address, user_agent, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $admin_id,
            $action,
            json_encode($details, JSON_UNESCAPED_UNICODE),
            $ip,
            substr($user_agent, 0, 255),
            $status
        ]);
    } catch (Exception $e) {
        error_log("Log yazma hatası: " . $e->getMessage());
    }
}

/**
 * İstemci IP'sini Getir
 */
function get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    }
    
    return filter_var(trim($ip), FILTER_VALIDATE_IP) ?: '';
}

/**
 * IP Engelli Mi Kontrol Et
 */
function is_ip_blocked($ip = null) {
    global $pdo;
    
    $ip = $ip ?? get_client_ip();
    
    try {
        $stmt = $pdo->prepare("SELECT id FROM blocked_ips WHERE ip_address = ? LIMIT 1");
        $stmt->execute([$ip]);
        return (bool)$stmt->fetch();
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Ziyaretçi Analizi Kaydet
 */
function log_visitor() {
    global $pdo;
    
    $ip = get_client_ip();
    
    if (is_ip_blocked($ip)) {
        http_response_code(403);
        die('Erişim Engellendi');
    }
    
    $session_id = session_id();
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $page = $_SERVER['REQUEST_URI'] ?? '';
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO visitor_analytics (ip_address, user_agent, referer, page_visited, session_id)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$ip, $user_agent, $referer, $page, $session_id]);
    } catch (Exception $e) {
        error_log("Ziyaretçi kaydı hatası: " . $e->getMessage());
    }
}

/**
 * E-posta Gönder
 */
function send_email($to, $subject, $message, $headers = []) {
    $settings = get_site_settings();
    
    if (empty($settings['smtp_host'])) {
        // SMTP ayarlanmadıysa PHP mail() kullan
        $email_headers = "MIME-Version: 1.0" . "\r\n";
        $email_headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        
        return @mail($to, $subject, $message, $email_headers);
    }
    
    // Eğer PHPMailer kuruluysa kullan
    try {
        if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
            require_once __DIR__ . '/../vendor/autoload.php';
            
            $mail = new PHPMailer\PHPMailer\PHPMailer();
            $mail->isSMTP();
            $mail->Host = $settings['smtp_host'];
            $mail->Port = $settings['smtp_port'] ?? 587;
            $mail->SMTPAuth = true;
            $mail->Username = $settings['smtp_username'];
            $mail->Password = $settings['smtp_password'];
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->CharSet = 'UTF-8';
            
            $mail->setFrom($settings['smtp_from_email'], $settings['site_name']);
            $mail->addAddress($to);
            $mail->Subject = $subject;
            $mail->Body = $message;
            $mail->isHTML(true);
            
            return $mail->send();
        }
    } catch (Exception $e) {
        error_log("E-posta gönderme hatası: " . $e->getMessage());
    }
    
    return false;
}

/**
 * CSRF Token Oluştur
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token Doğrula
 */
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token ?? '');
}

/**
 * JSON Yanıt
 */
function json_response($success, $message = '', $data = []) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Sayfalama
 */
function paginate($total, $per_page = 10, $current_page = 1) {
    $total_pages = ceil($total / $per_page);
    $current_page = max(1, min($current_page, $total_pages));
    $offset = ($current_page - 1) * $per_page;
    
    return [
        'total' => $total,
        'per_page' => $per_page,
        'current_page' => $current_page,
        'total_pages' => $total_pages,
        'offset' => $offset,
        'has_prev' => $current_page > 1,
        'has_next' => $current_page < $total_pages
    ];
}

/**
 * Resim Yükle
 */
function upload_image($file, $folder = 'products') {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['success' => false, 'error' => 'Dosya yükleme hatası'];
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($ext, ALLOWED_IMAGE_TYPES)) {
        return ['success' => false, 'error' => 'Desteklenmeyen dosya türü'];
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'error' => 'Dosya çok büyük'];
    }
    
    $filename = uniqid() . '.' . $ext;
    $folder_path = UPLOAD_PATH . '/' . $folder;
    
    if (!is_dir($folder_path)) {
        mkdir($folder_path, 0755, true);
    }
    
    $filepath = $folder_path . '/' . $filename;
    
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false, 'error' => 'Dosya taşıma hatası'];
    }
    
    return [
        'success' => true,
        'filename' => $filename,
        'url' => UPLOAD_URL . '/' . $folder . '/' . $filename,
        'path' => $filepath
    ];
}

/**
 * Meta Etiketleri Oluştur
 */
function generate_meta_tags($page) {
    $title = escape($page['title'] ?? '');
    $description = escape($page['meta_description'] ?? '');
    $keywords = escape($page['meta_keywords'] ?? '');
    $canonical = escape($page['canonical_url'] ?? SITE_URL);
    
    $meta = "\n<!-- SEO Meta Etiketleri -->\n";
    $meta .= "<title>$title - " . SITE_NAME . "</title>\n";
    $meta .= "<meta name=\"description\" content=\"$description\">\n";
    $meta .= "<meta name=\"keywords\" content=\"$keywords\">\n";
    $meta .= "<link rel=\"canonical\" href=\"$canonical\">\n";
    
    return $meta;
}
?>