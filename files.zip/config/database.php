<?php
/**
 * XBT Yazılım Hizmetleri - Veritabanı Bağlantısı
 * PHP 8.4 + MySQL 8.0
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'agac_xbtdtbs');
define('DB_USER', 'agac_xbtyntc');
define('DB_PASS', 'D7Ba21IiGh%Bf24D');
define('DB_CHARSET', 'utf8mb4');
define('DB_PORT', 3306);

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ]
    );
    
} catch (PDOException $e) {
    error_log("❌ Veritabanı Bağlantı Hatası: " . $e->getMessage());
    die("Veritabanı bağlantısı başarısız. Sistem Yöneticisine başvurun.");
}
?>