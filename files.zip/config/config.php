<?php
/**
 * Ağaç Dizayn - Ana Konfigürasyon
 */

// Site Bilgileri
define('SITE_URL', 'https://www.agacdizayn.com');
define('SITE_NAME', 'Ağaç Dizayn');
define('ADMIN_PATH', '/xbtadmin');

// Klasör Yolları
define('BASE_PATH', dirname(dirname(__FILE__)));
define('CONFIG_PATH', BASE_PATH . '/config');
define('PUBLIC_PATH', BASE_PATH . '/public');
define('UPLOAD_PATH', PUBLIC_PATH . '/uploads');
define('UPLOAD_URL', SITE_URL . '/uploads');
define('LOG_PATH', BASE_PATH . '/logs');

// Güvenlik
define('SESSION_TIMEOUT', 3600); // 1 saat
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 15); // dakika

// Dosya Yüklemesi
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('MAX_FILE_SIZE', 5242880); // 5MB
define('THUMB_WIDTH', 300);
define('THUMB_HEIGHT', 300);

// SEO
define('SEO_TITLE_MAX', 60);
define('SEO_DESC_MAX', 160);

// Debug Mode (Production'da FALSE olmalı)
define('DEBUG_MODE', false);

// Zaman Dilimi
date_default_timezone_set('Europe/Istanbul');

// Error Reporting
if (!DEBUG_MODE) {
    error_reporting(0);
    ini_set('display_errors', 0);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

// Log Dizini Kontrolü
if (!is_dir(LOG_PATH)) {
    @mkdir(LOG_PATH, 0755, true);
}

// Upload Dizini Kontrolü
if (!is_dir(UPLOAD_PATH)) {
    @mkdir(UPLOAD_PATH, 0755, true);
}

// Session Başlat
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>