<?php
/**
 * XBT Yazılım Hizmetleri - Güvenlik Sınıfı
 */

class Security {
    
    /**
     * PBKDF2 ile Şifre Hash'le
     */
    public static function hash_password($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    /**
     * Şifreyi Doğrula
     */
    public static function verify_password($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * 2FA TOTP Secret Oluştur
     */
    public static function generate_totp_secret() {
        return bin2hex(random_bytes(20));
    }
    
    /**
     * 2FA TOTP Kodu Doğrula
     */
    public static function verify_totp($secret, $code) {
        require_once __DIR__ . '/../vendor/autoload.php';
        
        $totp = new OTPHP\TOTP($secret);
        return $totp->verify($code);
    }
    
    /**
     * Yedek Kodlar Oluştur
     */
    public static function generate_backup_codes($count = 10) {
        $codes = [];
        for ($i = 0; $i < $count; $i++) {
            $codes[] = bin2hex(random_bytes(4));
        }
        return $codes;
    }
    
    /**
     * SQL Injection Koruması (PDO ile)
     */
    public static function sanitize_sql($value) {
        // PDO prepared statements kullan - burası otomatik
        return $value;
    }
    
    /**
     * XSS Koruması
     */
    public static function sanitize_html($html) {
        return htmlspecialchars($html, ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * CSRF Koruması
     */
    public static function generate_token() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    public static function verify_token($token) {
        return isset($_SESSION['csrf_token']) && 
               hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Rate Limiting
     */
    public static function check_rate_limit($key, $limit = 5, $window = 60) {
        $cache_key = "rate_limit_" . $key;
        
        if (!isset($_SESSION[$cache_key])) {
            $_SESSION[$cache_key] = [];
        }
        
        $now = time();
        $_SESSION[$cache_key] = array_filter($_SESSION[$cache_key], function($time) use ($now, $window) {
            return $time > ($now - $window);
        });
        
        if (count($_SESSION[$cache_key]) >= $limit) {
            return false;
        }
        
        $_SESSION[$cache_key][] = $now;
        return true;
    }
    
    /**
     * Dosya İndirme Güvenliği
     */
    public static function safe_file_download($filepath) {
        if (!file_exists($filepath) || strpos(realpath($filepath), realpath(UPLOAD_PATH)) !== 0) {
            return false;
        }
        return true;
    }
    
    /**
     * Content Security Policy
     */
    public static function set_security_headers() {
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: SAMEORIGIN");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");
        header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;");
    }
}