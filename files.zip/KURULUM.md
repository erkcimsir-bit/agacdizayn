# XBT Yazılım Hizmetleri - Kurulum Rehberi

## Sistem Gereksinimleri

- **PHP**: 8.4+
- **MySQL**: 8.0+
- **Apache** veya Nginx
- **OpenSSL** (HTTPS için)

## Adım 1: Dosyaları Yükle

1. cPanel'de File Manager'a giriş yapın
2. `public_html` klasörüne tüm dosyaları yükleyin
3. Dosya izinlerini ayarlayın:
   - `config/` → 755
   - `public/uploads/` → 777
   - `logs/` → 777

## Adım 2: Veritabanını Oluştur

1. cPanel'de **phpMyAdmin**'e giriş yapın
2. Yeni bir veritabanı oluşturun: `xbtsoftware_db`
3. SQL dosyasını import edin:
   - `xbtsoftware_db.sql`

## Adım 3: Konfigürasyonu Düzenle

1. `config/database.php` dosyasını açın
2. Veritabanı bilgilerini güncelleyin:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'xbtsoftware_db');
   define('DB_USER', 'kullanici_adi');
   define('DB_PASS', 'sifre');