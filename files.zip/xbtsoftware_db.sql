-- Ağaç Dizayn - Veritabanı Şeması
-- PHP 8.4 + MySQL 8.0

-- Tablo 1: Site Ayarları
CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `site_name` VARCHAR(255) NOT NULL DEFAULT 'Ağaç Dizayn',
  `site_description` TEXT,
  `site_keywords` TEXT,
  `logo_path` VARCHAR(255),
  `favicon_path` VARCHAR(255),
  `google_verification` TEXT,
  `google_analytics` TEXT,
  `google_recaptcha_key` VARCHAR(255),
  `google_recaptcha_secret` VARCHAR(255),
  `google_maps_key` VARCHAR(255),
  `maintenance_mode` TINYINT DEFAULT 0,
  `maintenance_message` TEXT,
  `smtp_host` VARCHAR(255),
  `smtp_port` INT,
  `smtp_username` VARCHAR(255),
  `smtp_password` VARCHAR(255),
  `smtp_from_email` VARCHAR(255),
  `whatsapp_number` VARCHAR(20),
  `whatsapp_enabled` TINYINT DEFAULT 0,
  `ping_search_engines` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 2: Admin Kullanıcıları (2FA ile)
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `username` VARCHAR(100) UNIQUE NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `two_factor_enabled` TINYINT DEFAULT 1,
  `two_factor_secret` VARCHAR(255),
  `backup_codes` JSON,
  `last_login` DATETIME,
  `last_login_ip` VARCHAR(45),
  `failed_attempts` INT DEFAULT 0,
  `locked_until` DATETIME,
  `active` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 3: Diller
CREATE TABLE IF NOT EXISTS `languages` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `code` VARCHAR(10) UNIQUE NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `is_default` TINYINT DEFAULT 0,
  `active` TINYINT DEFAULT 1,
  `sort_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 4: Menüler
CREATE TABLE IF NOT EXISTS `menus` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `language_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `icon` VARCHAR(100),
  `parent_id` INT,
  `sort_order` INT DEFAULT 0,
  `active` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`language_id`) REFERENCES `languages`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`parent_id`) REFERENCES `menus`(`id`) ON DELETE CASCADE,
  INDEX `idx_language_active` (`language_id`, `active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 5: Sayfalar
CREATE TABLE IF NOT EXISTS `pages` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `language_id` INT NOT NULL,
  `menu_id` INT,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `content` LONGTEXT,
  `meta_description` TEXT,
  `meta_keywords` TEXT,
  `og_title` VARCHAR(255),
  `og_description` TEXT,
  `og_image` VARCHAR(255),
  `canonical_url` VARCHAR(255),
  `published` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`language_id`) REFERENCES `languages`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`menu_id`) REFERENCES `menus`(`id`) ON DELETE SET NULL,
  UNIQUE KEY `unique_slug_language` (`slug`, `language_id`),
  INDEX `idx_published_language` (`published`, `language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 6: Kategoriler
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `language_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `image` VARCHAR(255),
  `parent_id` INT,
  `sort_order` INT DEFAULT 0,
  `meta_description` TEXT,
  `meta_keywords` TEXT,
  `active` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`language_id`) REFERENCES `languages`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`parent_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_slug_language_cat` (`slug`, `language_id`),
  INDEX `idx_active_language` (`active`, `language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 7: Ürünler/Hizmetler
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `language_id` INT NOT NULL,
  `category_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` LONGTEXT,
  `short_description` TEXT,
  `image` VARCHAR(255),
  `gallery` JSON,
  `meta_description` TEXT,
  `meta_keywords` TEXT,
  `sort_order` INT DEFAULT 0,
  `featured` TINYINT DEFAULT 0,
  `active` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`language_id`) REFERENCES `languages`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_slug_language_prod` (`slug`, `language_id`),
  INDEX `idx_featured_active` (`featured`, `active`),
  INDEX `idx_category_active` (`category_id`, `active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 8: Sliders
CREATE TABLE IF NOT EXISTS `sliders` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `language_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `image` VARCHAR(255) NOT NULL,
  `link` VARCHAR(255),
  `button_text` VARCHAR(100),
  `sort_order` INT DEFAULT 0,
  `active` TINYINT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`language_id`) REFERENCES `languages`(`id`) ON DELETE CASCADE,
  INDEX `idx_active_language_slider` (`active`, `language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 9: İletişim Mesajları
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `language_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20),
  `subject` VARCHAR(255) NOT NULL,
  `message` LONGTEXT NOT NULL,
  `status` ENUM('new', 'read', 'replied', 'archived') DEFAULT 'new',
  `reply_message` LONGTEXT,
  `replied_by` INT,
  `replied_at` DATETIME,
  `read_at` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`language_id`) REFERENCES `languages`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`replied_by`) REFERENCES `admin_users`(`id`) ON DELETE SET NULL,
  INDEX `idx_status_created` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 10: Ziyaretçi Analizi
CREATE TABLE IF NOT EXISTS `visitor_analytics` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `ip_address` VARCHAR(45) NOT NULL,
  `country` VARCHAR(100),
  `country_code` VARCHAR(10),
  `region` VARCHAR(100),
  `city` VARCHAR(100),
  `latitude` DECIMAL(8, 6),
  `longitude` DECIMAL(9, 6),
  `user_agent` TEXT,
  `referer` VARCHAR(500),
  `page_visited` VARCHAR(255),
  `session_id` VARCHAR(255),
  `visit_duration` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ip_created` (`ip_address`, `created_at`),
  INDEX `idx_country_created` (`country`, `created_at`),
  INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 11: IP Engel Listesi
CREATE TABLE IF NOT EXISTS `blocked_ips` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `ip_address` VARCHAR(45) NOT NULL UNIQUE,
  `reason` VARCHAR(255),
  `blocked_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`blocked_by`) REFERENCES `admin_users`(`id`) ON DELETE SET NULL,
  INDEX `idx_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tablo 12: Güvenlik Logları
CREATE TABLE IF NOT EXISTS `security_logs` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `admin_id` INT,
  `action` VARCHAR(100) NOT NULL,
  `details` JSON,
  `ip_address` VARCHAR(45),
  `user_agent` TEXT,
  `status` ENUM('success', 'failed', 'warning') DEFAULT 'success',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admin_users`(`id`) ON DELETE SET NULL,
  INDEX `idx_admin_created` (`admin_id`, `created_at`),
  INDEX `idx_status_created` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Varsayılan veriler
INSERT INTO `languages` (`code`, `name`, `is_default`, `active`) VALUES
('tr', 'Türkçe', 1, 1),
('en', 'English', 0, 1);

INSERT INTO `site_settings` (`site_name`, `site_description`, `smtp_from_email`) VALUES
('Ağaç Dizayn', 'Profesyonel ağaç tasarım ve dekorasyon hizmetleri', 'info@agacdizayn.com');

-- Admin Kullanıcı (Şifre: admin123 - LÜTFENDEĞİŞTİRİN!)
-- Şifre Hash: password_hash('admin123', PASSWORD_BCRYPT)
INSERT INTO `admin_users` (`username`, `email`, `password_hash`, `two_factor_enabled`) VALUES
('admin', 'admin@agacdizayn.com', '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36UNjWba', 1);